//***auth_rt.js is the main router for user authentication backend, its html rendering,
//*** and its necessary access/refresh tokens (if any).

// import the express router and necessary modules
const express = require("express");
const mysql = require("mysql2/promise");
const path = require("path");
const jwt = require("jsonwebtoken");
const { is } = require("type-is");
const cookieParser = require("cookie-parser");

// Create a new router object
const router = express.Router();
// Serve static files from the 'public' directory
router.use(express.static(path.join(__dirname, "public")));
// Parse cookies in the request headers
router.use(cookieParser());
// Import the 'dotenv' module for loading environment variables
require("dotenv").config();

//Import custom middleware
const verifyLogin = require("../middleware/verifyLogin");

//** Database
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
});

// Generate Access Token
function generateAccessToken(user) {
  return jwt.sign(user, process.env.ACCESS_TOKEN_SECRET, { expiresIn: "1m" });
}

// Generate Refresh Token
function generateRefreshToken(user) {
  return jwt.sign(user, process.env.REFRESH_TOKEN_SECRET, { expiresIn: "1d" });
}

// main router (auth.ejs form)
router.route("/").get(verifyLogin, (req, res) => {
  if (req.isLoggedIn) {
    //if user is logged in
    //display error

    console.log("You are already logged in! Redirecting to myprofile page");
    return res.redirect("/myprofile");
  }
  // otherwise, render the auth.ejs template
  return res.render("auth", {
    title: "Login/Register",
    siteName: "Worst Buy",
  });
});

// Route to get token expiration times
router.route("/token_status").get((req, res) => {
  const accessToken = req.cookies.accessToken;
  const refreshToken = req.cookies.refreshToken;

  if (!refreshToken) {
    return res
      .status(403)
      .json({ message: "No refresh token found! (You must not be logged in)" }); // Forbidden if no refresh token
  }

  // Decode and get expiration times
  try {
    const accessTokenPayload = jwt.verify(
      accessToken,
      process.env.ACCESS_TOKEN_SECRET,
      { complete: true }
    );
    const refreshTokenPayload = jwt.verify(
      refreshToken,
      process.env.REFRESH_TOKEN_SECRET,
      { complete: true }
    );

    const currentTime = Math.floor(Date.now() / 1000); // Current time in seconds
    // Calculate the time remaining for each token by subtracting the current time
    // from the expiration time. Use the ternary operator to handle cases where
    // the expiration time might be undefined, ensuring a default value of 0.
    const accessTokenExpiresAt = accessTokenPayload.payload.exp
      ? accessTokenPayload.payload.exp - currentTime
      : 0;
    const refreshTokenExpiresAt = refreshTokenPayload.payload.exp
      ? refreshTokenPayload.payload.exp - currentTime
      : 0;

    //displays on command prompt
    console.log(`Access Token Expires In: ${accessTokenExpiresAt} seconds`);
    console.log(`Refresh Token Expires In: ${refreshTokenExpiresAt} seconds`);

    return res.status(200).json({
      //displayed on the website inspect console
      // Send the time remaining in seconds as a response
      accessTokenExpiresAt,
      refreshTokenExpiresAt,
    });
  } catch (err) {
    return res.status(403).json({
      message: "Invalid tokens. Cannot display time remaining of each",
    });
  }
});

// Refresh token endpoint (***only use .json with status not sendStatus)
router
  .route("/restart_token")
  .post((req, res) => {
    const refreshToken = req.cookies.refreshToken;

    if (!refreshToken) {
      return res
        .status(403)
        .json({
          message: "No refresh token found! (You must not be logged in)",
        });
    }

    // Verify the refresh token
    jwt.verify(refreshToken, process.env.REFRESH_TOKEN_SECRET, (err, user) => {
      if (err) {
        return res.status(403).json({ message: "Invalid refresh token" });
      }

      const accessToken = req.cookies.accessToken;

      // Check if the access token is valid and not expired
      try {
        const accessTokenPayload = jwt.verify(
          accessToken,
          process.env.ACCESS_TOKEN_SECRET
        );

        // If the access token is valid, just return a status indicating it's still valid
        return res
          .status(200)
          .json({ message: "Access token is still valid." });
      } catch (err) {
        // If the access token is expired, generate a new one
        const newAccessToken = generateAccessToken({ email: user.email });

        // Renew the access token cookie
        res.cookie("accessToken", newAccessToken, {
          httpOnly: true,
          secure: process.env.NODE_ENV === "production",
          maxAge: 1 * 60 * 1000, // 1 minute
        });

        return res
          .status(201)
          .json({ message: "Access token refreshed! (It was expired!)" });
      }
    });
  })
  //.get request that receives the user object stored in the access token
  .get(verifyLogin, (req, res) => {
    //if user is logged in (access token found and valid), so return the user object
    if (req.isLoggedIn) {
      const accessToken = req.cookies.accessToken;
      return res.status(200).json({ user: jwt.decode(accessToken) });
    }
    //access token not found or invalid
    return res.status(403).json({
      message:
        "You are not logged in! (No access token found), so cannot recieve user object",
    });
  });

router.route("/login_request").post(async (req, res) => {
  const { email, password } = req.body;

  try {
    //query to check if the email and password match
    const [rows] = await pool.query(
      "SELECT * FROM users WHERE email = ? AND password = ?",
      [email, password]
    );
    if (rows.length > 0) {
      const user = { email: email }; // Store user's email in the token payload

      // Generate tokens
      const accessToken = generateAccessToken(user); //token itself lasts 5 minutes
      const refreshToken = generateRefreshToken(user); //token itself lasts 1 day

      // Set cookies for tokens
      res.cookie("accessToken", accessToken, {
        //cookie for access token
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        maxAge: 1 * 60 * 1000, // 1 minutes for access token's cookie
      });

      res.cookie("refreshToken", refreshToken, {
        //cookie for refresh token
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        maxAge: 24 * 60 * 60 * 1000, // 1 day for refresh token's cookie
      });

      return res.status(200).json({ message: "Login successful!" });
    } else {
      return res.status(401).json({ message: "Invalid credentials" });
    }
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Error occurred with mysql database or query" });
  }
});

router.route("/register_request").post(async (req, res) => {
  const { email, password } = req.body;
  try {
    // Check if the email already exists
    const [existingUser] = await pool.query(
      "SELECT * FROM users WHERE email = ?",
      [email]
    );
    if (existingUser.length > 0) {
      return res.status(409).json({ message: "Email already registered" });
    }

    // If email is not found, insert the new user
    await pool.query("INSERT INTO users (email, password) VALUES (?, ?)", [
      email,
      password,
    ]);
    return res.status(200).json({ message: "Registration successful!" });
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Error occurred with mysql database or query" });
  }
});

module.exports = router;
