//***auth_rt.js is the main router for user authentication backend, its html rendering,
//*** and its necessary access/refresh tokens (if any).

// import the express router and necessary modules
const express = require("express");
const mysql = require("mysql2/promise");
const path = require("path");
const jwt = require("jsonwebtoken");
const { is } = require("type-is");
const cookieParser = require("cookie-parser");

// Create a new router object
const router = express.Router();
// Serve static files from the 'public' directory
router.use(express.static(path.join(__dirname, "public")));
// Parse cookies in the request headers
router.use(cookieParser());
// Import the 'dotenv' module for loading environment variables
require("dotenv").config();

//Import custom middleware
const verifyLogin = require("../middleware/verifyLogin");
const verifyCartAccessToken = require("../middleware/verifyCartAccessToken");
const { access } = require("fs");

//** Database
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
});

// Generate Access Token
function generateAccessToken(user) {
  return jwt.sign(user, process.env.ACCESS_TOKEN_SECRET, { expiresIn: "1m" });
}

// Generate Refresh Token
function generateRefreshToken(user) {
  return jwt.sign(user, process.env.REFRESH_TOKEN_SECRET, { expiresIn: "1d" });
}

// main router (auth.ejs form)
router.route("/")
  .get(verifyLogin, verifyCartAccessToken, (req, res) => {
    if (req.isLoggedIn) {
      //if user is logged in
      //log redirect on command prompt

      console.log("You are already logged in! Redirecting to myprofile page"); // output to terminal
      return res.redirect("/myprofile");
    }

    //fields needed to be calculated to render the partial header.ejs view
    loggedIn = req.isLoggedIn; // Get the 'req.isLoggedIn' from middleware
    cart = req.cart; // Get the 'req.cart' from middleware
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0); // Calculate total items in cart

    // otherwise, render the auth.ejs template
    return res.render("auth", {
      title: "Login/Register",
      siteName: "Worst Buy", // (header.ejs)
      loggedIn, //should be false already (header.ejs)
      totalItems // (header.ejs)

    });
  });

// Route to get token expiration times
router.route("/token_status")
  .get((req, res) => {
    const accessToken = req.cookies.accessToken;
    const refreshToken = req.cookies.refreshToken;

    if (!refreshToken) {
      console.log("No refresh token found! (Not logged in): (token_status: GET)"); // output to terminal
      return res
        .status(201)
        .json({ message: "No refresh token found! (Not logged in): (token_status: GET)" }); // Forbidden if no refresh token
    }

    // Decode and get expiration times
    try {
      const accessTokenPayload = jwt.verify(
        accessToken,
        process.env.ACCESS_TOKEN_SECRET,
        { complete: true }
      );
      const refreshTokenPayload = jwt.verify(
        refreshToken,
        process.env.REFRESH_TOKEN_SECRET,
        { complete: true }
      );

      const currentTime = Math.floor(Date.now() / 1000); // Current time in seconds
      // Calculate the time remaining for each token by subtracting the current time
      // from the expiration time. Use the ternary operator to handle cases where
      // the expiration time might be undefined, ensuring a default value of 0.
      const accessTokenExpiresAt = accessTokenPayload.payload.exp
        ? accessTokenPayload.payload.exp - currentTime
        : 0;
      const refreshTokenExpiresAt = refreshTokenPayload.payload.exp
        ? refreshTokenPayload.payload.exp - currentTime
        : 0;

        //calculate days, hours, minutes, and seconds
      const accessTokenTimeRemaining = calculateTimeRemaining(accessTokenExpiresAt);
      const refreshTokenTimeRemaining = calculateTimeRemaining(refreshTokenExpiresAt);

      const accessExpirationText = `Access Token Expires In: ${accessTokenTimeRemaining.days} days ${accessTokenTimeRemaining.hours} hours ${accessTokenTimeRemaining.minutes} minutes and ${accessTokenTimeRemaining.seconds} seconds`;
      const refreshExpirationText = `Refresh Token Expires In: ${refreshTokenTimeRemaining.days} days ${refreshTokenTimeRemaining.hours} hours ${refreshTokenTimeRemaining.minutes} minutes and ${refreshTokenTimeRemaining.seconds} seconds`;

      // Display the time remaining for each token to terminal
      console.log(accessExpirationText);
      console.log(refreshExpirationText);

      return res.status(200).json({
        //displayed on the website inspect console
        // Send the time remaining in seconds as a response
       accessExpiration: accessExpirationText,
        refreshExpiration: refreshExpirationText,
      });
    } catch (err) {
      console.error("Invalid token(s). Cannot display time remaining of each (token_status: GET)"); // output to terminal
      return res.status(403).json({
        message: "Invalid token(s). Cannot display time remaining of each (token_status: GET)",
      });
    }
  });

// Refresh token endpoint (***only use .json with status not sendStatus)
router
  .route("/restart_token")
  .post(async (req, res) => {
    const refreshToken = req.cookies.refreshToken;
  
    try {
      // Verify the refresh token
      const user = jwt.verify(refreshToken, process.env.REFRESH_TOKEN_SECRET);
  
      const accessToken = req.cookies.accessToken;
  
      // Check if the access token is valid and not expired
      try {
        jwt.verify(accessToken, process.env.ACCESS_TOKEN_SECRET);
        // If the access token is valid, just return a status indicating it's still valid
        return res.status(200).json({ message: "Access token is still valid." });
      } catch (err) {
        // If the access token is expired, generate a new one
        const newAccessToken = generateAccessToken({ email: user.email });
  
        // Renew the access token cookie
        res.cookie("accessToken", newAccessToken, {
          httpOnly: true,
          secure: process.env.NODE_ENV === "production",
          maxAge: 1 * 60 * 1000, // 1 minute
        });
  
        console.log("Access token refreshed! (It was expired!)"); // output to terminal
        return res.status(202).json({ message: "Access token refreshed! (It was expired!)" });
      }
    } catch (err) {
      console.log("Invalid refresh token. (Re-login or register)"); // output to terminal
      return res.status(203).json({ message: "Invalid refresh token. (Re-login or register)" });
    }
  })
  //.get request that receives the user object stored in the access token
  .get(verifyLogin, (req, res) => {
    //if user is logged in (access token found and valid), so return the user object
    if (req.isLoggedIn) {
      const accessToken = req.cookies.accessToken;
      console.log("User object recieved to be displayed or logged! (restart_token: GET)"); // output to terminal
      return res.status(200).json({ user: jwt.decode(accessToken) });
    }
    //access token not found or invalid
    console.log("No access token found! (Not logged in) Cannot recieve user object to be displayed or logged (restart_token: GET)"); // output to terminal
    return res.status(201).json({
      message:
        "No access token found! (Not logged in) Cannot recieve user object to be displayed or logged (restart_token: GET)",
    });
  });

router.route("/login_request").post(async (req, res) => {
  const { email, password } = req.body;

  try {
    //query to check if the email and password match
    const [rows] = await pool.query(
      "SELECT * FROM users WHERE email = ? AND password = ?",
      [email, password]
    );
    if (rows.length > 0) {
      const user = { email: email }; // Store user's email in the token payload

      // Generate tokens
      const accessToken = generateAccessToken(user); //token itself lasts 5 minutes
      const refreshToken = generateRefreshToken(user); //token itself lasts 1 day

      // Set cookies for tokens
      res.cookie("accessToken", accessToken, {
        //cookie for access token
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        maxAge: 1 * 60 * 1000, // 1 minutes for access token's cookie
      });

      res.cookie("refreshToken", refreshToken, {
        //cookie for refresh token
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        maxAge: 24 * 60 * 60 * 1000, // 1 day for refresh token's cookie
      });

      return res.status(200).json({ message: "Login successful!" });
    } else {
      return res.status(401).json({ message: "Invalid credentials" });
    }
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Error occurred with mysql database or query" });
  }
});

router.route("/register_request").post(async (req, res) => {
  const { email, password } = req.body;
  try {
    // Check if the email already exists
    const [existingUser] = await pool.query(
      "SELECT * FROM users WHERE email = ?",
      [email]
    );
    if (existingUser.length > 0) {
      return res.status(409).json({ message: "Email already registered" });
    }

    // If email is not found, insert the new user
    await pool.query("INSERT INTO users (email, password) VALUES (?, ?)", [
      email,
      password,
    ]);
    return res.status(200).json({ message: "Registration successful!" });
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Error occurred with mysql database or query" });
  }
});

//utility to calculate days, hours, minutes, and seconds

function calculateTimeRemaining(time) {
  const days = Math.floor(time / (24 * 60 * 60)); // Calculate remaining days
  const hours = Math.floor((time % (24 * 60 * 60)) / (60 * 60)); // Calculate remaining hours
  const minutes = Math.floor((time % (60 * 60)) / 60); // Calculate remaining minutes
  const seconds = time % 60; // Calculate remaining seconds

  return { days, hours, minutes, seconds };
}

module.exports = router;
