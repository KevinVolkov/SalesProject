//the profile page will include the logout and home button functionality
const homebutton = document.getElementById('home-button'); // Home button
const logoutButton = document.getElementById('logout-button'); // Logout button

//send post request to backend to log out on logout button click
logoutButton.addEventListener('click', async () => {
  try {
    // Send logout request to the backend
    const response = await fetch("/auth/logout", {
      method: "POST", // HTTP method
    });

    // Parse response data
    const result = await response.json(); //the type of result is a promise, so we use await to wait for the promise to resolve.
    // a promise is an object that represents the eventual completion (or failure) of an asynchronous operation, and its resulting value.

    // Check if logout was successful
    if (response.ok) {
      //response.ok is a boolean that indicates if the response was successful. it is true if the status code is in the range 200-299
      //display success message and return to the home page
      console.log(result); // Log success message
      window.location.href = "/"; // Redirect to the home page
    } else {
      console.log(result.message); // Log error message
    }
  } catch (error) {
    console.error("Error logging out:", error);
  }
});