// checkout_rt.js
// Import the necessary modules
const express = require("express");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const path = require("path");

const router = express.Router();
router.use(express.static(path.join(__dirname, "public")));
router.use(cookieParser());
require("dotenv").config();

// Middleware to verify cart access token
const verifyCartAccessToken = (req, res, next) => {
  const accessToken = req.cookies.cartAccessToken;

  try {
    // Verify the access token
    const cartData = jwt.verify(
      accessToken,
      process.env.CART_ACCESS_TOKEN_SECRET
    );
    req.cart = cartData.cart; // Attach cart data to the request
  } catch (err) {
    req.cart = []; // If token is invalid or expired, set an empty cart
    console.log("Cart access token is invalid or expired. Please refresh the page.");
  }

  next(); // Proceed to the next middleware or route
};

// Route to render the checkout page with cart data
router.route("/")
  .get(verifyCartAccessToken, (req, res) => {
    const cart = req.cart || [];

    // If the cart is empty, redirect back to the cart page
    if (cart.length === 0) {
      return res.redirect("/cart");
    }

    // Render the checkout page with the cart data
    res.render("checkout", { cart });
  })
  // Route to handle checkout process (POST request)
  .post(verifyCartAccessToken, (req, res) => {
    const cart = req.cart || [];

    // If the cart is empty, return an error response
    if (cart.length === 0) {
      return res.status(400).json({ message: "Cart is empty!" });
    }

    // Calculate total price for checkout
    const totalPrice = cart.reduce(
      (sum, item) => sum + item.quantity * parseFloat(item.price),
      0
    );

    // (Payment gateway integration should go here)

    // Clear the cart after successful checkout
    const emptyCart = [];
    const accessToken = generateCartAccessToken(emptyCart);
    res.cookie("cartAccessToken", accessToken, { httpOnly: true });

    // Send success response with order details
    return res.status(200).json({
      message: "Checkout successful!",
      totalAmount: totalPrice.toFixed(2),
      cart: emptyCart,
    });
  });

// Utility to generate a cart access token
const generateCartAccessToken = (cartData) => {
  const accessToken = jwt.sign(
    { cart: cartData },
    process.env.CART_ACCESS_TOKEN_SECRET,
    { expiresIn: "1d" } // Token lasts for 1 day
  );
  return accessToken;
};

module.exports = router;

