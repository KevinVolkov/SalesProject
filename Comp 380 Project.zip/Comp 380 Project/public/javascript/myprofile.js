//*** myprofile.js is the client side code that is SPECIFICALLY for to the profile screen.

document.addEventListener("DOMContentLoaded", () => {
  const homebutton = document.getElementById('home-button'); // Home button
  const logoutButton = document.getElementById('logout-button'); // Logout button

  logoutButton.addEventListener('click', async () => {
    try {
      // Send logout request to the backend
      const response = await fetch("/auth/logout", {
        method: "POST",
      });

      // Parse response data
      const result = await response.json();

      // Log the message from the response
      console.log(result.message);
      //redirect to the home page
      window.location.href = "/";

    } catch (error) {
      console.error("Error logging out:", error);
    }
  });
});

//check if access token is valid. if so do nothing
//if not, redirect to login page
  // Function to check if the access token is valid
  async function checkAccessToken() {
    try {
      const response = await fetch("/auth/restart_token", {
        method: "GET",
        credentials: "include" // Include cookies in the request
      });

      if (response.status === 200) {
        // Token is valid
        const data = await response.json();
        console.log("User info:", data.user); // Log the user information
      } else {
        // Token is invalid, redirect to login
        console.log("Access token is invalid or expired. Redirecting to login...");
        //timeout for 1 second
        setTimeout(() => {
          window.location.href = "/auth"; // Redirect to login page
        }, 1000);
      }
    } catch (error) {
      console.error("Error checking access token:", error);
    }
  }

  // Call the function to check the access token
  checkAccessToken();

