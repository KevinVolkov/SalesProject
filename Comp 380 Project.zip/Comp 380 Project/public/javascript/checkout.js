// checkout.js
document.addEventListener("DOMContentLoaded", () => {

  document
    .getElementById("checkout-form")
    .addEventListener("submit", async (e) => {
      e.preventDefault();

      const formData = new FormData(e.target);
      const data = Object.fromEntries(formData.entries());

      try {
        const response = await fetch("/checkout", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        });

        const result = await response.json();
        document.getElementById("message").textContent =
          result.message || "Checkout completed!";
      } catch (error) {
        console.error("Error:", error);
        document.getElementById("message").textContent =
          "There was an error during checkout.";
      }
    });
});
