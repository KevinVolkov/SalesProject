// server.js

// Core modules
const express = require("express");
const path = require("path");
const https = require("https");
const fs = require("fs");
const os = require("os");

// Third-party modules
const helmet = require("helmet");
const axios = require("axios");
require("dotenv").config();

//** Express app initialization
const app = express();

//** Middleware setup
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(helmet());
app.use(express.static(path.join(__dirname, "public")));

// Set up EJS as the view engine
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");

//** Database config
const { verifyDatabase } = require("./config/dbconfig.js");

//** Routers
const rootRouter = require("./routes/root_rt");
app.use("/", rootRouter);
const authRouter = require("./routes/auth_rt");
app.use("/auth", authRouter);
const shopRouter = require("./routes/shop_rt");
app.use("/shop", shopRouter);
const cartRouter = require("./routes/cart_rt");
app.use("/cart", cartRouter);
const checkoutRouter = require("./routes/checkout_rt");
app.use("/checkout", checkoutRouter);
const myprofileRouter = require("./routes/myprofile_rt");
app.use("/myprofile", myprofileRouter);

//** SSL setup
let sslOptions;
try {
  sslOptions = {
    key: fs.readFileSync(path.join(__dirname, "certs", "privkey3.pem")),
    cert: fs.readFileSync(path.join(__dirname, "certs", "cert3.pem")),
    ca: fs.readFileSync(path.join(__dirname, "certs", "chain3.pem")),
  };
} catch (error) {
  console.error("Failed to load SSL certificates:", error);
  process.exit(1);
}

// Utility function to fetch public IP
async function getPublicIP() {
  try {
    const response = await axios.get("https://api.ipify.org?format=json");
    return response.data.ip;
  } catch (error) {
    console.error("Error fetching public IP:", error);
    return "(ERR: CANNOT GET PUBLIC IP)";
  }
}

// Utility function to fetch private IP
function getPrivateIP() {
  const networkInterfaces = os.networkInterfaces();
  let privateIP = '';

  for (const interfaceKey in networkInterfaces) {
    const networkInterface = networkInterfaces[interfaceKey];
    for (const address of networkInterface) {
      if (address.family === 'IPv4' && !address.internal) {
        privateIP = address.address;
        break;
      }
    }
    if (privateIP) break;
  }
  return privateIP || 'No private IP found';
}

//** Start the HTTPS server
async function launchSite() {
  try {
    await verifyDatabase();

    const httpsServer = https.createServer(sslOptions, app);
    const publicIP = await getPublicIP();
    const privateIP = getPrivateIP();
    const HOST = "0.0.0.0";
    const PORT = process.env.PORT || 443;

    httpsServer.listen(PORT, HOST, () => {
      console.log(`
-----------------------------------------------------------------------------------------------------------------
Worst Buy HTTPS Server is running at:
-----------------------------------------------------------------------------------------------------------------
Local:  https://localhost:${PORT}         (accessible only on this machine) 
        https://${privateIP}:${PORT}      (for other devices on the same network)

Public: https://${publicIP}:${PORT}   (Make sure Network Firewall allows Port ${PORT} for inbound connections)
-----------------------------------------------------------------------------------------------------------------
\n`);
    });
  } catch (error) {
    console.error("Site could not be launched!:", error);
  }
}

//** Driver code
launchSite();
