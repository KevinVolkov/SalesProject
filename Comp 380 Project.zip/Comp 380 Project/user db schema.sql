-- Create 'users' table if it doesn't exist
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,     -- Unique ID for each user
    email VARCHAR(255) NOT NULL,           -- User's email (required)
    password VARCHAR(255) NOT NULL,        -- User's password (required)
    is_admin BOOLEAN DEFAULT FALSE         -- Admin flag (default is false)
);

-- Insert a sample user (optional) -- You can uncomment this to insert a sample admin user
-- INSERT INTO users (email, password, is_admin) VALUES ('admin@example.com', 'adminpassword', TRUE);

-- Display all users (email, password, is_admin status)
SELECT * FROM users;
