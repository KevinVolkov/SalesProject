
const express = require('express');
const router = express.Router();

// render the auth.ejs template and pass data to it
router.get('/', (req, res) => {
    res.render('auth', {
      title: 'Login/Register',
      siteName: 'Worst Buy'
    });
  });
  
  
  router.get('/login_request', (req, res) => { 
    res.send('You are not supposed to be here! -Jason Clone');
  });
  
  // Handle login requests
  router.post('/login_request', async (req, res) => {
    const { email, password } = req.body;
    try {
      const [rows] = await pool.query('SELECT * FROM users WHERE email = ? AND password = ?', [email, password]);
      if (rows.length > 0) {
        res.status(200).json({ message: 'Login successful!' });
      } else {
        res.status(401).json({ message: 'Invalid credentials' });
      }
    } catch (error) {
      res.status(500).json({ message: 'Error occurred' });
    }
  });
  
  router.get('/register_request', (req, res) => {
    res.send('You are not supposed to be here!  -Jason Clone');
  });
  
  // Handle register requests
  router.post('/register_request', async (req, res) => {
    const { email, password } = req.body;
    try {
      await pool.query('INSERT INTO users (email, password) VALUES (?, ?)', [email, password]);
      res.status(200).json({ message: 'Registration successful!' });
    } catch (error) {
      res.status(500).json({ message: 'Error occurred' });
    }
  });
  
module.exports = router; //export the router object