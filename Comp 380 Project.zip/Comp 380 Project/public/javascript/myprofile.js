document.addEventListener("DOMContentLoaded", () => {
  const homebutton = document.getElementById('home-button'); // Home button
  const logoutButton = document.getElementById('logout-button'); // Logout button

  logoutButton.addEventListener('click', async () => {
    try {
      // Send logout request to the backend
      const response = await fetch("/auth/logout", {
        method: "POST",
      });

      // Parse response data
      const result = await response.json();

      // Log the message from the response
      console.log(result.message);

    } catch (error) {
      console.error("Error logging out:", error);
    }
  });
});
