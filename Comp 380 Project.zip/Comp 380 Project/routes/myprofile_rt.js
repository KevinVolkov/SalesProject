//***myprofile_rt.js is the main router for the user's profile backend, its html rendering,
//*** and its necessary access/refresh tokens (if any).

const express = require('express');
const router = express.Router();
const mysql = require('mysql2/promise');
require('dotenv').config();
const cookieParser = require("cookie-parser");
const jwt = require("jsonwebtoken");

// Parse cookies in the request headers
router.use(cookieParser());

// Database for users
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB1_NAME,
});


//router for profile page
// Add this route to fetch user profile
router.route("/").get(async (req, res) => {
  const accessToken = req.cookies.accessToken;

  // Verify access token
  jwt.verify(accessToken, process.env.ACCESS_TOKEN_SECRET, async (err, user) => {
    if (err) {
      return res.status(403).json({ message: "Invalid access token! Cannot fetch profile!" });
    }

    // Fetch the user's email from the database
    try {
      const [rows] = await pool.query("SELECT email FROM users WHERE email = ?", [user.email]); //user.email is stored in the token payload
      if (rows.length > 0) {
        const userEmail = rows[0].email; //
        res.render("myprofile", {
          title: "User Profile",
          siteName: "Worst Buy",
          email: userEmail, // Pass the email to the EJS template
        });
      } else {
        return res.status(404).json({ message: "User not found" });
      }
    } catch (error) {
      return res.status(500).json({ message: "Database query error" });
    }
  });
});



module.exports = router; // Export the router object
