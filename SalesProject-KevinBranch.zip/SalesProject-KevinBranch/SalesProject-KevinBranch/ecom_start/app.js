//app.js
//** library imports
const express = require('express');
//const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
const stripe = require('stripe')('your_stripe_secret_key');
const bcrypt = require('bcryptjs');

//Kevin 10/27/24 start want https
const fs = require('fs');
const path = require('path');
const https = require('https');

const session = require('express-session');
const flash = require('connect-flash');


//** custom imports

const sequelize = require('./config/db');  // Ensure this points to the right file
const createDatabase = require('./config/createDatabase');
const populateItemsIfEmpty = require('./config/populateItems');
const Customer = require('./models/Customer'); //not used
//imported routes*************
const customerRoutes = require('./routes/customers'); // Include customer routes
const itemsRoute = require('./routes/items'); // Import the items route
const orderRoute = require('./routes/order'); // Import the order route

//** app setup
const app = express(); // Create an Express app

//** library middleware
app.set('view engine', 'ejs'); // Set the view engine to EJS
app.use(bodyParser.urlencoded({ extended: true })); // Parse application/x-www-form-urlencoded
app.use(express.static('public')); // Serve static files from the 'public' folder

//** custom middleware (routers)

app.use('/customers', customerRoutes); // customers router
app.use('/items', itemsRoute); // Use the items route for requests to the /items path
app.use('/order', orderRoute); // Use the order route for requests to the /order path

//** Configure the session and its middleware
app.use(session({
  secret: 'yourSecretKey', // A secret key used to encrypt the session cookies
  resave: false, // Don't save session if unmodified
  saveUninitialized: true, // Always create a session to ensure the customer can log in
  cookie: { secure: false } // set to true in production when using HTTPS
}));

// Configure the flash middleware which provides feedback messages
app.use(flash());

// Configure the middleware to store the customer and cart length in the locals object
app.use((req, res, next) => {
  res.locals.customer = req.session.customer || null; // `customer` is saved in session on login
  //Kevin 10/27/24 start
  const cart = req.session.cart || [];
  res.locals.cartCount = cart.length;
  //Kevin 10/27/24 end
  next();
});


//** server setup and execution

//Kevin 10/27/24, I declare below for https //const PORT = process.env.PORT || 3001;//3000 already in use, why?
// start database connection and server
async function startServer() {
  try {
    // Create the database if it doesn't exist
    await createDatabase(); //from createDatabase.js

    // Sync the Sequelize models with the database, No, it adds email_2, email_3
    //await sequelize.sync({ alter: true }); // `alter: true` ensures tables are updated
/* dod not do this, I do this before
    // Start the Express server
    app.listen(PORT, () => {
      console.log(`My Server started on port ${PORT}`);
    });*/
  } catch (error) {
    console.error('Unable to connect to MySQL:', error);
  }
}

startServer(); // Start the server (create database and catch errors)


//** sequelize.sync():
//** sequelize is the object exported from the db.js file.
//** This method is used to synchronize your Sequelize models 
//** with the database. It ensures that the database reflects the structure of your defined models.
//** Remember: sequelize = require('./config/db');

//for populating table if empty ******************
// Sync sequelize and then populate items if empty
sequelize.sync().then(async () => {
  console.log('Connected to MySQL');
  
  // Call the function to populate the items table if it's empty
  await populateItemsIfEmpty();
  
  // Start the server after population is complete
 // app.listen(3000, () => {      console.log('Server started on port 3000');  });
}).catch(err => {
  console.error('Unable to connect to MySQL:', err);
});


//** routes that are only defined in app.js (not in separate route files)

app.get('/', (req, res) => {
  const cartCount = req.session.cart ? req.session.cart.length : 0;
  res.render('index', {
      title: 'Welcome to ABC Sales',
      user: req.user, // Pass user info if needed (not used in this route)
      cartCount: cartCount,//Kevin fix 10/27/24
  });
});



// Other middleware and configurations...
app.get('/checkout', (req, res) => {
  if (!req.session.customer) {
      return res.redirect('/customers/login'); // Redirect to login if not authenticated
  }
  res.render('checkout', 
    { 
      customer: req.session.customer,
      user: req.user // Pass user info if needed
    });
});

// Include routes for login, register, and logout
app.get('/login', (req, res) => {
 // res.render('login');
 res.render('login', {
  title: 'Please Login to ABC Sales',
  user: req.user // Pass user info if needed
});
});

app.get('/register', (req, res) => {
   res.render('register', {
   title: 'Please Register with ABC Sales',
   user: req.user // Pass user info if needed
 });
 });

/*
app.get('/logout', (req, res) => {
  req.logout();  // Use this if Passport.js is being used
  res.render('logout',{
    user: req.user // Pass user info if needed
  });
});
*/
app.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.log("Could not destroy session. (/logout)");
      return res.redirect('/');
    }
    console.log("Session destroyed successfully. (/logout)");
    res.redirect('/');
  });
});


//** https
// Load SSL certificates (This one self signed, but replace with the paths to my SSL certificate and key when have)
const options = {
  key: fs.readFileSync(path.join(__dirname, 'key.pem')),  // private key
  cert: fs.readFileSync(path.join(__dirname, 'cert.pem')) // certificate
};//Kevin 10/27/24 end want https

/* Kevin Volkov: I now do https 
app.listen(3000, () => {
  console.log('Server started on port 3000');
});*/
const server = https.createServer(options, app);
// Start the server on port 3000 (or another port)
//already above const PORT = process.env.PORT || 3000;
const PORT = 443;//3000;//process.env.PORT;// || 3001;//3000 already in use, why?
server.listen(PORT, () => {
    console.log(`Server running securely (https) on port ${PORT}`);
});