// import the express router and necessary modules
const express = require("express");
const mysql = require("mysql2/promise");
const path = require("path");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");

// Create a new router object
const router = express.Router();
// Serve static files from the 'public' directory
router.use(express.static(path.join(__dirname, "public")));
// Parse cookies in the request headers
router.use(cookieParser());
// Import the 'dotenv' module for loading environment variables
require("dotenv").config();

// Database for products
const pool1 = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB2_NAME,
});

// Database for users (to see if user is admin)
const pool2 = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB1_NAME,
});

// Organizes each endpoint by http request type
router.route("/").get(async (req, res) => {
  try {
    // Fetch products from the database
    const [products] = await pool1.query("SELECT * FROM products");
    const searchTerm = req.query.search || ""; // Get the search term from the query parameter

    // Filter products based on the search term
    const filteredProducts = products.filter((product) =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    // Check if the user is logged in by refresh token
    const refreshToken = req.cookies.refreshToken;
    let isAdmin = false;

    // Verify refresh token
    jwt.verify(
      refreshToken,
      process.env.REFRESH_TOKEN_SECRET,
      async (err, user) => {
        if (err) {
          // Render without admin status if no refresh token (cannot get admin status if not logged in)
          res.render("shop", {
            title: "Shop",
            siteName: "Worst Buy",
            products: filteredProducts,
            searchTerm,
            isAdmin: false,
          });
          console.log("No refresh token found! Cannot get admin status.");
        return;
        }

        // Check if user is an admin
        const [rows] = await pool2.query(
          "SELECT email, is_admin FROM users WHERE email = ?",
          [user.email]
        );
        if (rows.length > 0) {
          isAdmin = rows[0].is_admin;
        }

        // Render the shop page with admin status
        res.render("shop", {
          title: "Shop",
          siteName: "Worst Buy",
          products: filteredProducts,
          searchTerm,
          isAdmin,
        });
      }
    );
  } catch (error) {
    console.error("Error fetching products:", error);
    res.render("shop", {
      title: "Shop",
      siteName: "Worst Buy",
      products: [],
      searchTerm,
      error: "Unable to fetch products. Please try again later.",
    });
  }
});

// Route to handle adding a new product (POST request)
router.route("/add_product").post(async (req, res) => {
  const { product_id, name, price, image_url, } = req.body;

  try {
    await pool1.query(
      "INSERT INTO products (id, name, price, image_url) VALUES (?, ?, ?, ?)", // Insert a new product into the database
      [product_id, name, price, image_url]
    );
    res.redirect("/"); // Redirect to the shop page after adding the product
  } catch (error) {
    console.error("Error adding product:", error);
    res.status(500).json({ message: "Failed to add product." });
  }
});

// Route to handle editing a product (POST request)
router.route("/edit_product").post(async (req, res) => {
  const { new_id, name, price, image_url, product_id } = req.body;

  try { // Update the product in the database
    await pool1.query(
      "UPDATE products SET id = ?, name = ?, price = ?, image_url = ? WHERE id = ?",
      [new_id, name, price, image_url, product_id]
    );
    res.redirect("/"); // Redirect to the shop page after editing the product
  } catch (error) {
    console.error("Error editing product:", error);
    res.status(500).json({ message: "Failed to edit product." });
  }
});

// Route to handle deleting a product (POST request)
router.route("/delete_product").post(async (req, res) => {
  const { product_id } = req.body;

  try {
    await pool1.query("DELETE FROM products WHERE id = ?", [product_id]);
    res.redirect("/"); // Redirect to the shop page after deleting the product
  } catch (error) {
    console.error("Error deleting product:", error);
    res.status(500).json({ message: "Failed to delete product." });
  }
});

// Export the router object
module.exports = router;