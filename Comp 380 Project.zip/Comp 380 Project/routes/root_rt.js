//***root_rt.js is the main router for home page backend, its html rendering,
//*** and its necessary access/refresh tokens (if any).

// import the express router and necessary modules
const express = require("express");
const mysql = require("mysql2/promise");
const path = require("path");
const jwt = require("jsonwebtoken");
const { is } = require("type-is");
const cookieParser = require("cookie-parser");

// Create a new router object
const router = express.Router();
// Serve static files from the 'public' directory
router.use(express.static(path.join(__dirname, "public")));
// Parse cookies in the request headers
router.use(cookieParser());
// Import the 'dotenv' module for loading environment variables
require("dotenv").config();


//imported custom middleware
const verifyCartAccessToken = require("../middleware/verifyCartAccessToken.js"); // Imported custom middleware
const verifyLogin = require("../middleware/verifyLogin.js"); // Imported custom middleware


//organizes each endpoint by http request type in the order they are written in the router object.
router
  .route("/")
   // render the root.ejs template and pass data to it
  .get(verifyLogin, verifyCartAccessToken, (req, res) => {
    loggedIn = req.isLoggedIn; // Get the 'req.isLoggedIn' from middleware
    cart = req.cart; // Get the 'req.cart' from middleware

    // Calculate total items in cart
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0); // Sum of all quantities
    res.render('root', {
      title: 'Home',
      siteName: 'Worst Buy',
      loggedIn,
      totalItems,
    });
  });


module.exports = router; // Export the router object

