//********************* COPY AND PASTE THIS CODE INTO OTHER ROUTE JS FILES
// import the express router and necessary modules
const express = require('express');
const mysql = require('mysql2/promise');
const path = require('path');

// Create a new router object
const router = express.Router();
// Serve static files from the 'public' directory
router.use(express.static(path.join(__dirname, 'public')));

// Import the 'dotenv' module for loading environment variables
require('dotenv').config();

// Create a MySQL connection pool for handling database queries
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB1_NAME
});
//********************* COPY AND PASTE THIS CODE INTO OTHER ROUTE JS FILES

// render the shop.ejs template and pass data to it
router.get('/', (req, res) => {
    const products = [ //images on products page
      { name: 'Product 1', image: '/product images/jasonclone.png', price: 19.99 },
      { name: 'Product 2', image: '/product images/jasonclone.png', price: 29.99 },
      { name: 'Product 3', image: '/product images/jasonclone.png', price: 39.99 }
    ];
    res.render('shop', {
      title: 'Shop',
      siteName: 'Worst Buy',
      products
    });
  });

module.exports = router; // Export the router object