document.addEventListener("DOMContentLoaded", () => {
  // Handle adding a new product
  const addProductForm = document.querySelector(".add-product-form");
  if (addProductForm) {
    addProductForm.addEventListener("submit", async (e) => {
      e.preventDefault();

      const newProductId = document.querySelector(
        ".new-product-id-input"
      ).value;
      const newProductName = document.querySelector(
        ".new-product-name-input"
      ).value;
      const newProductPrice = document.querySelector(
        ".new-product-price-input"
      ).value;
      const newProductDescription = document.querySelector(
        ".new-product-description-input"
      ).value;
      const newProductImageUrl = document.querySelector(
        ".new-product-image-url-input"
      ).value;

      const response = await fetch("/shop/add_product", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          product_id: newProductId,
          name: newProductName,
          price: newProductPrice,
          description: newProductDescription,
          image_url: newProductImageUrl,
        }),
      });

      if (response.ok) {
        window.location.reload(); // Reload to see the new product
      } else {
        alert("Failed to add product.");
      }
    });
  }

  // Handle editing a product
  const editProductForms = document.querySelectorAll(".edit-product-form");
  editProductForms.forEach((form) => {
    form.addEventListener("submit", async (e) => {
      e.preventDefault();

      const productId = form.querySelector(".current-product-id").value; // Original ID
      const newProductId = form.querySelector(".updated-product-id").value; // New ID
      const productName = form.querySelector(".edit-product-name-input").value;
      const productPrice = form.querySelector(
        ".edit-product-price-input"
      ).value;
      const productDescription = form.querySelector(
        ".edit-product-description-input"
      ).value;
      const productImageUrl = form.querySelector(
        ".edit-product-image-url-input"
      ).value;

      const response = await fetch("/shop/edit_product", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          product_id: productId, // This is the ID you're updating
          new_id: newProductId, // This is the new ID you want to set
          name: productName,
          price: productPrice,
          description: productDescription,
          image_url: productImageUrl,
        }),
      });

      if (response.ok) {
        window.location.reload(); // Reload to see the updated product
      } else {
        alert(response.statusText);
      }
    });
  });

  // Handle deleting a product
  const deleteProductForms = document.querySelectorAll(".delete-product-form");
  deleteProductForms.forEach((form) => {
    form.addEventListener("submit", async (e) => {
      e.preventDefault();

      const productId = form.querySelector(".delete-product-id-input").value;

      const response = await fetch("/shop/delete_product", {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          product_id: productId,
        }),
      });

      if (response.ok) {
        window.location.reload(); // Reload to see the updated list
      } else {
        alert("Failed to delete product.");
      }
    });
  });

  document.querySelectorAll(".add-to-cart").forEach((button) => {
    button.addEventListener("click", () => {
      const productId = button.dataset.productId;
      const name = button.dataset.name;
      //set quantity to the value of the input field
      const quantity = parseInt(
        document.querySelector(`#quantity-${productId}`).value
      );
      const price = parseFloat(button.dataset.price); // Convert price to a float

      fetch("/cart/add", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ productId, name, quantity, price }),
      })
        .then(() => {
          // Handle success
          window.location.reload(); // Reload the page to update cart
        })
        .catch((error) => {
          // Handle errors
          alert("Error adding item:", error);
        });
    });
  });
});
