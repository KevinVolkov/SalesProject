//the login and profile button functionality will only be included in this script
//because this script is included to any .ejs file that has the login and profile button

const loginButton = document.getElementById("login-button"); // Login button
const profileButton = document.getElementById("myprofile-button"); // Profile button

// verify if the access and refresh tokens are valid by sending a request to the server
// Function to refresh the access token
async function refreshAccessToken() {
  //called every time the page is loaded or refreshed
  try {
    // First fetch to restart token
    const refreshResponse = await fetch("auth/restart_token", {
      //to see if the access token is still valid
      method: "POST",
      credentials: "include", // Important for sending cookies
    });

    if (refreshResponse.ok) {
      //if the access token is still valid
      const data = await refreshResponse.json();
      console.log(data.message);

      // Second fetch to get the refreshed access token information (user data)
      const userResponse = await fetch("auth/restart_token", {
        //for debugging purposes
        method: "GET",
        credentials: "include", // Important for sending cookies
      });
      const userData = await userResponse.json();

      //fetch to get time remaining on access and refresh tokens
      const timeResponse = await fetch("auth/token_status", {
        //for debugging purposes
        method: "GET",
        credentials: "include", // Important for sending cookies
      });
      const timeData = await timeResponse.json();
      console.log(timeData); //display current time remaining on access and refresh token
      console.log(userData.user); // display data in access token: { email: '...

      //****** IMPORTANT: remove login button and replace with profile button on-
      //***ANY ejs file that has the login and profile button
      //****** THIS IS THE ONLY REASON TO INCLUDE THIS SCRIPT IN AN EJS FILE OTHER THAN DEBUGGING
      profileButton.classList.remove("hidden"); // Show the profile button
      loginButton.classList.add("hidden"); // Hide the login button
      //if you are logged out, the else if case below should occur and the login button will stay visible

      //if the access token is not valid, redirect to the login page
    } else if (refreshResponse.status === 403) {
      console.log("access or refresh token expired. Please log in again."); // Log error message to console
    }
  } catch (error) {
    console.error("Error refreshing access token:", error);
  }
}

// Call this function every time the page is loaded or refreshed
window.addEventListener("load", () => {
  refreshAccessToken(); // Refresh the access token on page load
});

// Go to register/login screen (auth.ejs) when the login/register button is clicked
loginButton.addEventListener("click", () => {
  //redirect to the auth page even if in deeper url path
  window.location.href = "/auth"; // Redirect to the auth page
});

// Go to profile page when the profile button is clicked
profileButton.addEventListener("click", () => {
  //redirect to the profile page
  window.location.href = "/myprofile"; // Redirect to the profile page
});
