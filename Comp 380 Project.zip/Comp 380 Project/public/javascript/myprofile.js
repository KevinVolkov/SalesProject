document.addEventListener("DOMContentLoaded", () => {


  // user profile features (editing user profile)

  // admin profile features (editing users in database)
  
});
