const express = require('express');
const router = express.Router();

// render the shop.ejs template and pass data to it
router.get('/', (req, res) => {
    const products = [ //images on products page
      { name: 'Product 1', image: '/product images/jasonclone.png', price: 19.99 },
      { name: 'Product 2', image: '/product images/jasonclone.png', price: 29.99 },
      { name: 'Product 3', image: '/product images/jasonclone.png', price: 39.99 }
    ];
    res.render('shop', {
      title: 'Shop',
      siteName: 'Worst Buy',
      products
    });
  });

module.exports = router; // Export the router object