// cart_rt.js
// Import the necessary modules
const express = require("express");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const path = require("path");

const router = express.Router();
router.use(express.static(path.join(__dirname, "public")));
router.use(cookieParser());
require("dotenv").config();

// Utility to generate a cart access token
const generateCartAccessToken = (cartData) => {
  // The token lasts for 1 day
  const accessToken = jwt.sign(
    { cart: cartData },
    process.env.CART_ACCESS_TOKEN_SECRET,
    { expiresIn: "1d" }
  );
  return accessToken;
};

// Middleware to verify cart access token
const verifyCartAccessToken = (req, res, next) => {
  const accessToken = req.cookies.cartAccessToken;

  try {
    // Verify the access token
    const cartData = jwt.verify(
      accessToken,
      process.env.CART_ACCESS_TOKEN_SECRET
    );
    req.cart = cartData.cart; // Attach cart data to the request
  } catch (err) {
    req.cart = []; // If token is invalid or expired, set an empty cart
    alert("Cart access token is invalid or expired. Please refresh the page.");
  }

  next(); // Proceed to the next middleware or route
};

// Route to get the cart access token expiration time
router.route("/token_status").get((req, res) => {
  const accessToken = req.cookies.cartAccessToken;

  // Check if the access token exists
  if (!accessToken) {
    return res.status(403).json({ message: "No cart access token found!" });
  }

  // Decode and get the expiration time
  try {
    const accessTokenPayload = jwt.verify(
      accessToken,
      process.env.CART_ACCESS_TOKEN_SECRET,
      { complete: true }
    );

    const currentTime = Math.floor(Date.now() / 1000); // Current time in seconds

    // Calculate the time remaining for the cart access token
    const accessTokenExpiresAt = accessTokenPayload.payload.exp
      ? accessTokenPayload.payload.exp - currentTime
      : 0;

    // Display on command prompt
    console.log(
      `Cart Access Token Expires In: ${accessTokenExpiresAt} seconds`
    );

    return res.status(200).json({
      accessTokenExpiresAt, // Send the time remaining in seconds as a response
    });
  } catch (err) {
    return res.status(403).json({
      message: "Invalid cart access token. Cannot display time remaining.",
    });
  }
});

// Route to render the cart page with EJS (GET request)
router.route("/")
  .get(verifyCartAccessToken, (req, res) => {
    const cart = req.cart || []; // `req.cart` is set by the verifyCartAccessToken middleware

    // Calculate total price and items
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0); // Sum of all quantities
    const totalPrice = cart.reduce(
      (sum, item) => sum + item.quantity * parseFloat(item.price),
      0
    ); // Sum of all prices

    // Render the cart EJS view
    res.render("cart", {
      cart,
      totalItems,
      totalPrice,
    });
  });

// Route to get cart items
router.route("/cartItems").get(verifyCartAccessToken, (req, res) => {
  const cart = req.cart || [];
  res.json(cart);
});

// Routes for adding, updating, and removing items from the cart
router.route("/add").post(verifyCartAccessToken, (req, res) => {
  const { productId, name, quantity, price } = req.body;
  const parsedPrice = Number(price); // Ensure price is a number
  const floatPrice = parseFloat(parsedPrice); // Convert parsed price to a float
  let cart = req.cart || [];

  // Check if the item is already in the cart
  const existingItem = cart.find((item) => item.productId === productId);
  if (existingItem) {
    // Update the quantity if item already exists
    existingItem.quantity += quantity;
  } else {
    // Add new item to the cart
    cart.push({ productId, name, quantity, price: floatPrice });
  }

  // Regenerate the cart access token with updated cart
  const accessToken = generateCartAccessToken(cart);
  res.cookie("cartAccessToken", accessToken, { httpOnly: true });

  res.redirect("/cart"); // Redirect to the cart page
});

router.route("/update").put(verifyCartAccessToken, (req, res) => {
  const { productId, quantity } = req.body;
  let cart = req.cart || [];

  // Find the item to update
  const existingItem = cart.find((item) => item.productId === productId);
  if (existingItem) {
    existingItem.quantity = quantity; // Update the quantity
  }

  // Regenerate the cart access token with updated cart
  const accessToken = generateCartAccessToken(cart);
  res.cookie("cartAccessToken", accessToken, { httpOnly: true });

  res.redirect("/cart"); // Redirect to the cart page
});

router.route("/remove").delete(verifyCartAccessToken, (req, res) => {
  const { productId } = req.body; // productId now comes from the body
  let cart = req.cart || [];

  // Filter out the item to be removed
  cart = cart.filter((item) => item.productId !== productId);

  // Regenerate the cart access token with updated cart
  const accessToken = generateCartAccessToken(cart);
  res.cookie("cartAccessToken", accessToken, { httpOnly: true });

  res.redirect("/cart"); // Redirect to the cart page
});

router.route("/clear").delete(verifyCartAccessToken, (req, res) => {
  const cart = []; // Clear the cart

  // Regenerate the cart access token with an empty cart
  const accessToken = generateCartAccessToken(cart);
  res.cookie("cartAccessToken", accessToken, { httpOnly: true });

  res.redirect("/cart"); // Redirect to the cart page
});

module.exports = router;

