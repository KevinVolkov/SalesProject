// shop_rt.js
// import the express router and necessary modules
const express = require("express");
const mysql = require("mysql2/promise");
const path = require("path");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const { error } = require("console");

// Create a new router object
const router = express.Router();
// Serve static files from the 'public' directory
router.use(express.static(path.join(__dirname, "public")));
// Parse cookies in the request headers
router.use(cookieParser());
// Import the 'dotenv' module for loading environment variables
require("dotenv").config();

//** Database
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
});

//middleware to verify if logged in by checking the login access token
const verifyLogin = (req, res, next) => {

  // Verify the access token
  jwt.verify(
    req.cookies.accessToken,
    process.env.ACCESS_TOKEN_SECRET,
    (err, user) => {
      if (err) {
        req.isLoggedIn = false; // Not logged in if token is invalid
      } else {
        req.isLoggedIn = true; // User is logged in
        req.user = user; // Save the user object for later use
      }
      next(); // Proceed to the next middleware or route
    }
  );
};

// Middleware to verify cart access token (in this case used to get cart item count for cart button)
const verifyCartAccessToken = (req, res, next) => {
  const accessToken = req.cookies.cartAccessToken;

  try {
    // Verify the access token
    const cartData = jwt.verify(
      accessToken,
      process.env.CART_ACCESS_TOKEN_SECRET
    );
    req.cart = cartData.cart; // Attach cart data to the request
  } catch (err) {
    req.cart = []; // If token is invalid or expired, set an empty cart
  }

  next(); // Proceed to the next middleware or route
};

// Organizes each endpoint by http request type
router.route("/").get(verifyLogin, verifyCartAccessToken, async (req, res) => {
  let searchTerm = ""; // Define searchTerm outside the try block
  let isAdmin = false; // Define isAdmin outside the try block
  loggedIn = req.isLoggedIn; // Get the 'isLoggedIn' status from the request
  cart = req.cart; // Get the 'req.cart' from middleware

  // Calculate total items in cart
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0); // Sum of all quantities

  try {
    // Fetch products from the database
    const [products] = await pool.query("SELECT * FROM products");
    searchTerm = req.query.search || ""; // Get the search term from the query parameter

    // Filter products based on the search term
    const filteredProducts = products.filter(
      (product) =>
        // Check if the product name or description includes the search term
        product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.description.toLowerCase().includes(searchTerm.toLowerCase())
    );

    if (!loggedIn) {
      // Render without admin status if not logged in (obviously)
      res.render("shop", {
        title: "Shop",
        siteName: "Worst Buy",
        products: filteredProducts,
        searchTerm,
        isAdmin: false,
        loggedIn,
        totalItems,
        error: null,
      });
      return;
    }

    user = req.user; // Get the user object from the middleware request

    // Check if user is an admin
    const [rows] = await pool.query(
      "SELECT email, is_admin FROM users WHERE email = ?",
      [user.email]
    );
    if (rows.length > 0) {
      // If user is found, get isadmin status
      isAdmin = rows[0].is_admin;
    }

    // Render the shop page with or without admin status
    res.render("shop", {
      title: "Shop",
      siteName: "Worst Buy",
      products: filteredProducts,
      searchTerm,
      isAdmin,
      loggedIn,
      totalItems,
      error: null,
    });
  } catch (error) {
    console.error("", error);
    res.render("shop", {
      title: "Shop",
      siteName: "Worst Buy",
      products: [],
      searchTerm,
      isAdmin,
      loggedIn,
      totalItems,
      error: "Error fetching products from database",
    });
  }
});

// Route to handle adding a new product (POST request)
router.route("/add_product").post(async (req, res) => {
  const { product_id, name, price, description, image_url } = req.body;

  try {
    await pool.query(
      "INSERT INTO products (id, name, price, description, image_url) VALUES (?, ?, ?, ?, ?)", // Insert a new product into the database
      [product_id, name, price, description, image_url]
    );
    res.redirect("/"); // Redirect to the shop page after adding the product
  } catch (error) {
    console.error("Error adding product:", error);
    res.status(500).json({ message: "Failed to add product." });
  }
});

// Route to handle editing a product (PUT request)
router.route("/edit_product").put(async (req, res) => {
  const { new_id, name, price, description, image_url, product_id } = req.body;

  try {
    const [result] = await pool.query(
      "UPDATE products SET id = ?, name = ?, price = ?, description = ?, image_url = ? WHERE id = ?",
      [new_id, name, price, description, image_url, product_id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Product not found." });
    }

    res.status(200).json({ message: "Product updated successfully!" });
  } catch (error) {
    console.error("Error editing product:", error);
    res.status(500).json({ message: "Failed to edit product." });
  }
});

// Route to handle deleting a product (DELETE request)
router.route("/delete_product").delete(async (req, res) => {
  const { product_id } = req.body;

  try {
    const [result] = await pool.query("DELETE FROM products WHERE id = ?", [
      product_id,
    ]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Product not found." });
    }

    res.status(200).json({ message: "Product deleted successfully!" });
  } catch (error) {
    console.error("Error deleting product:", error);
    res.status(500).json({ message: "Failed to delete product." });
  }
});

// Export the router object
module.exports = router;
