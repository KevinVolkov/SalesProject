
// Wait for the page to load
document.addEventListener("DOMContentLoaded", () => {
  // Get the login and profile buttons
  const loginButton = document.getElementById("login-button"); // Login button
  const profileButton = document.getElementById("myprofile-button"); // Profile button

  // Function to refresh the access token
  async function refreshAccessToken() {
    try {
      const refreshResponse = await fetch("auth/restart_token", {
        method: "POST",
        credentials: "include",
      });

      // Parse JSON data from response
      const data = await refreshResponse.json();

      // Log the message from the response
      console.log(data.message);

      if (refreshResponse.ok) {
        // Handle the successful response
        console.log("Access Token refreshed!");

        // Fetch user data
        const userResponse = await fetch("auth/restart_token", {
          method: "GET",
          credentials: "include",
        });

        if (userResponse.ok) {
          const userData = await userResponse.json();
          console.log(userData);
        } else {
          const errorData = await userResponse.json();
          console.log(errorData.message);
        }

        // Fetch token status
        const timeResponse = await fetch("auth/token_status", {
          method: "GET",
          credentials: "include",
        });

        if (timeResponse.ok) {
          const timeData = await timeResponse.json();
          console.log(timeData);
        } else {
          const errorTimeData = await timeResponse.json();
          console.log(errorTimeData.message);
        }

        // Update UI
        profileButton.classList.remove("hidden");
        loginButton.classList.add("hidden");
      }
    } catch (error) {
      console.error("Error refreshing access token:", error);
    }
  }

  // Call this function every time the page is loaded or refreshed
  window.addEventListener("load", () => {
    refreshAccessToken(); // Refresh the access token on page load
  });

  // Go to register/login screen (auth.ejs) when the login/register button is clicked
  loginButton.addEventListener("click", () => {
    window.location.href = "/auth"; // Redirect to the auth page
  });

  // Go to profile page when the profile button is clicked
  profileButton.addEventListener("click", () => {
    window.location.href = "/myprofile"; // Redirect to the profile page
  });
});
