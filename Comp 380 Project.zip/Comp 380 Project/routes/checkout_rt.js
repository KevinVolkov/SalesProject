// Import the necessary modules
const express = require("express");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const path = require("path");
const SibApiV3Sdk = require('sib-api-v3-sdk'); // Import Brevo SDK

const router = express.Router();
router.use(express.static(path.join(__dirname, "public")));
router.use(cookieParser());
require("dotenv").config();

// Initialize Brevo SDK for automated email sending
SibApiV3Sdk.ApiClient.instance.authentications['api-key'].apiKey = process.env.BREVO_API_KEY; // Use environment variable for API key

// Utility to generate a cart access token
const generateCartAccessToken = (cartData) => {
  const accessToken = jwt.sign(
    { cart: cartData },
    process.env.CART_ACCESS_TOKEN_SECRET,
    { expiresIn: "1d" } // Token lasts for 1 day
  );
  return accessToken;
};

// Middleware to verify cart access token
const verifyCartAccessToken = (req, res, next) => {
  const accessToken = req.cookies.cartAccessToken;

  try {
    // Verify the access token
    const cartData = jwt.verify(
      accessToken,
      process.env.CART_ACCESS_TOKEN_SECRET
    );
    req.cart = cartData.cart; // Attach cart data to the request
  } catch (err) {
    req.cart = []; // If token is invalid or expired, set an empty cart
    console.log("Cart access token is invalid or expired. Please refresh the page.");
  }

  next(); // Proceed to the next middleware or route
};

// Route to render the checkout page with cart data
router.route("/")
  .get(verifyCartAccessToken, (req, res) => {
    const cart = req.cart || [];

    // If the cart is empty, redirect back to the cart page
    if (cart.length === 0) {
      return res.redirect("/cart");
    }

    // Render the checkout page with the cart data
    res.render("checkout", { cart });
  })
  // Route to handle checkout process (POST request)
  .post(verifyCartAccessToken, async (req, res) => {
    const cartData = req.cart || [];
    const checkoutData = req.body.data;
    const paymentData = req.body.paymentInfo;

    // If the cart is empty, return an error response
    if (cartData.length === 0) {
      return res.status(400).json({ message: "Cart is empty!" });
    }

    // Calculate total price for checkout
    const totalPrice = cartData.reduce(
      (sum, item) => sum + item.quantity * parseFloat(item.price),
      0
    );

    // Prepare email data
    const emailData = {
      sender: { email: process.env.WORSTBUY_SENDER_EMAIL }, // Your sender email
      to: [{ email: checkoutData.email }], // Recipient email from the request body
      subject: 'Worstbuy Checkout Successful!', // Subject of the email
      htmlContent: `<strong>Your checkout was successful!</strong><br>

                    Total price: $${totalPrice.toFixed(2)}<br>
                    Order details: ${cartData.map((item) => `${item.name} x${item.quantity}`).join(",\n ")}<br>
                    Name: ${checkoutData.name}<br>
                    Address: ${checkoutData.address}<br>
                    City: ${checkoutData.city}<br>
                    State: ${checkoutData.state}<br>
                    Zip: ${checkoutData.zip}<br>
                    Shipping method: ${checkoutData["shipping-method"]}<br>
                    Payment method: ${paymentData.method}<br>
                    Total Price: $${totalPrice.toFixed(2)}<br>`,

    };

    // Send the email
    try {
      const apiInstance = new SibApiV3Sdk.TransactionalEmailsApi(); // Create an instance of the Transactional Emails API
      await apiInstance.sendTransacEmail(emailData); // Send the email
      console.log('Email sent successfully');
    } catch (error) {
      console.error('Error sending email:', error);
      return res.status(500).json({ message: 'Error during checkout.' });
    }

    // Clear the cart after successful checkout
    const emptyCart = [];
    const accessToken = generateCartAccessToken(emptyCart);
    res.cookie("cartAccessToken", accessToken, { httpOnly: true });

    // Send success response with order details
    return res.status(200).json({
      message: "Checkout successful!",
      price: totalPrice.toFixed(2),
      cartData: cartData,
      checkoutData: checkoutData,
      paymentData: paymentData,
    });
  });

module.exports = router;
