//*** myprofile.js is the client side code that is SPECIFICALLY for to the profile screen.


document.addEventListener("DOMContentLoaded", () => {


  const homebutton = document.getElementById("home-button"); // Home button
  const logoutButton = document.getElementById("logout-button"); // Logout button

  logoutButton.addEventListener("click", async () => {
    try {
      // Send logout request to the backend
      const response = await fetch("/auth/logout", {
        method: "POST",
      });

      // Parse response data
      const result = await response.json();

      // Log the message from the response
      console.log(result.message);
      //redirect to the home page
      window.location.href = "/";
    } catch (error) {
      console.error("Error logging out:", error);
    }
  });


});
