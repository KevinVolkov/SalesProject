// shop_rt.js
// Import the express router and necessary modules
const express = require("express");
const mysql = require("mysql2/promise");
const path = require("path");
const cookieParser = require("cookie-parser");
require("dotenv").config(); // Import dotenv module for loading environment variables

// Create a new router object
const router = express.Router();
// Serve static files from the 'public' directory
router.use(express.static(path.join(__dirname, "public")));

// Parse cookies in the request headers
router.use(cookieParser());

// Imported config
const upload = require("../config/multer"); // Import Multer config

// Imported custom middleware
const verifyCartAccessToken = require("../middleware/verifyCartAccessToken.js");
const verifyLogin = require("../middleware/verifyLogin.js");

// Database connection pool
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
});

// Route for the shop page
router.route("/").get(verifyLogin, verifyCartAccessToken, async (req, res) => {
  let searchTerm = req.query.search || ""; // Get the search term from query parameters
  let isAdmin = false; // Default admin status
  const loggedIn = req.isLoggedIn; // Get 'isLoggedIn' status from the request
  const cart = req.cart || []; // Get cart from middleware, default to empty array

  // Calculate total items in cart
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0); // Sum of all quantities

  try {
    // Fetch products from the database
    const [products] = await pool.query("SELECT * FROM products");

    // Filter products based on the search term
    const filteredProducts = products.filter(
      (product) =>
        product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.description.toLowerCase().includes(searchTerm.toLowerCase())
    );

    if (loggedIn) {
      const user = req.user; // Get user object from the middleware request
      if (!user) {
        throw new Error(
          "User not found! The user object from middleware is null."
        );
      }

      // Check if user is an admin
      const [rows] = await pool.query(
        "SELECT is_admin FROM users WHERE email = ?",
        [user.email]
      );
      if (rows.length > 0) {
        isAdmin = rows[0].is_admin;
      }
    }

    // Render the shop page
    res.render("shop", {
      title: "Shop",
      siteName: "Worst Buy",
      products: filteredProducts,
      searchTerm,
      isAdmin,
      loggedIn,
      totalItems,
      error: null,
    });
  } catch (error) {
    console.error("Error fetching products:", error);
    res.render("shop", {
      title: "Shop",
      siteName: "Worst Buy",
      products: [],
      searchTerm,
      isAdmin,
      loggedIn,
      totalItems,
      error: "Error fetching products from the database.",
    });
  }
});

// Route to handle adding a new product (POST request with file upload)
router
  .route("/add_product")
  .post(upload.single("productImage"), async (req, res) => {
    const { name, price, description } = req.body; // Extract other fields from req.body
    const image_path = req.file ? req.file.path : null; // Get the uploaded file path

    try {
      // Check if image_path is set and valid
      if (!image_path) {
        console.error("Image upload failed, no file uploaded."); //output to terminal
        return res
          .status(400)
          .json({ message: "Image upload failed, please try again." });
      }

      // Truncate the image path to be relative
      const relativeImagePath =
        "/" +
        path
          .relative(path.join(__dirname, "../public"), image_path)
          .replace(/\\/g, "/");
      console.log("Relative image path:", relativeImagePath);
      // Insert the product into the database
      await pool.query(
        "INSERT INTO products (name, price, description, image_path) VALUES (?, ?, ?, ?)",
        [name, price, description, relativeImagePath] // Store the relative path of the uploaded image
      );

      console.log("SUCCESS: Product added!"); //output to terminal
      res.status(200).json({ message: "Product added successfully!" });

    } catch (error) {
      console.error("Error adding product: " + error); //output to terminal
      res.status(500).json({ message: "Failed to add product." });
    }
  });

// Route to handle editing a product (PUT request with file upload)
router
  .route("/edit_product")
  .put(upload.single("productImage"), async (req, res) => {
    const { new_id, name, price, description, product_id } = req.body;

    try {
      // Fetch the current image path from the database (in case no new image is uploaded)
      const [rows] = await pool.query(
        "SELECT image_path FROM products WHERE id = ?",
        [product_id]
      );

      // Check if the product exists
      if (rows.length === 0) {
        console.error("Product not found! Cannot get its image_path."); //output to terminal
        return res
          .status(404)
          .json({
            message: "ERR: Product not found! Cannot get its image_path.",
          });
      }

      // Use the uploaded file path if provided, otherwise use the existing image path
      const image_path = req.file ? req.file.path : rows[0].image_path; //req.file gets the file from the form because of the multer middleware

      // Truncate the image path to be relative if it's set
      const relativeImagePath =
        "/" +
        path
          .relative(path.join(__dirname, "../public"), image_path)
          .replace(/\\/g, "/");

      // Update the product in the database
      const [result] = await pool.query(
        "UPDATE products SET id = ?, name = ?, price = ?, description = ?, image_path = ? WHERE id = ?",
        [new_id, name, price, description, relativeImagePath, product_id]
      ); 

      if (result.affectedRows === 0) {
        console.error("Product not found. (edit_product) "); //output to terminal
        return res.status(404).json({ message: "Product not found. (edit_product)" });
      }

      console.log("SUCCESS: Product updated!"); //output to terminal
      res.status(200).json({ message: "Product updated successfully!" });

    } catch (error) {
      console.error("Error editing product: " + error);
      res.status(500).json({ message: "Failed to edit product." });
    }
  });

// Route to handle deleting a product (DELETE request)
router.route("/delete_product")
.delete(async (req, res) => {
  const { product_id } = req.body;

  try {
    const [result] = await pool.query("DELETE FROM products WHERE id = ?", [
      product_id,
    ]);

    if (result.affectedRows === 0) {
      console.error("Product not found. (delete_product)"); //output to terminal
      return res.status(404).json({ message: "Product not found." });
    }
    console.log("SUCCESS: Product deleted!"); //output to terminal
    res.status(200).json({ message: "Product deleted successfully!" });
  } catch (error) {
    console.error("Error deleting product: " + error); //output to terminal
    res.status(500).json({ message: "Failed to delete product." });
  }
});

// Export the router object
module.exports = router;
