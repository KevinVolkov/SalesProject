//***myprofile_rt.js is the main router for the user's profile backend, its html rendering,
//*** and its necessary access/refresh tokens (if any).

const express = require('express');
const router = express.Router();
const mysql = require('mysql2/promise');
require('dotenv').config();


//router for profile page
router
  .route("/")
   // render the root.ejs template and pass data to it
  .get((req, res) => {
    res.render('myprofile', {
      title: 'Profile',
      siteName: 'Worst Buy',
    });
  });


module.exports = router; // Export the router object
