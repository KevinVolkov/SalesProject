//***shop_rt.js is the main router for shop page's backend, its html rendering,
//*** and its necessary access/refresh tokens (if any).

// import the express router and necessary modules
const express = require("express");
const mysql = require("mysql2/promise");
const path = require("path");
const jwt = require("jsonwebtoken");
const { is } = require("type-is");
const cookieParser = require("cookie-parser");

// Create a new router object
const router = express.Router();
// Serve static files from the 'public' directory
router.use(express.static(path.join(__dirname, "public")));
// Parse cookies in the request headers
router.use(cookieParser());
// Import the 'dotenv' module for loading environment variables
require("dotenv").config();

// Create a MySQL connection pool for handling database queries
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB1_NAME,
});

//organizes each endpoint by http request type in the order they are written in the router object.
router.route("/").get((req, res) => {
  const products = [
    // Example products
    {
      name: "Product 1",
      image: "/product images/jasonclone.png",
      price: 19.99,
    },
    {
      name: "Product 2",
      image: "/product images/jasonclone.png",
      price: 29.99,
    },
    {
      name: "Product 3",
      image: "/product images/jasonclone.png",
      price: 39.99,
    },
  ];

  const searchTerm = req.query.search || ""; // Get the search term from the query parameter, default to empty string
  // Filter products based on the search term
  const filteredProducts = products.filter((product) => // Filter products based on the search term
    product.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Render the shop page with the filtered products and search term
  res.render("shop", {
    title: "Shop",
    siteName: "Worst Buy",
    products: filteredProducts,
    searchTerm,
  });
});

module.exports = router; // Export the router object
