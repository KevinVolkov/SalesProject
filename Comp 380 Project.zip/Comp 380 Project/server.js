const express = require('express');
const mysql = require('mysql2/promise');
const path = require('path');
require('dotenv').config();

const app = express();
app.use(express.json());

// Serve static files
app.use(express.static(__dirname + '/public'));

// Set up EJS as the view engine
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// this dynamically renders the page based on the data passed to it (html rendering)
app.get('/', (req, res) => {
  // Sample data to pass to the template

  const products = [ //images on products page
    { name: 'Product 1', image: '/product images/jasonclone.png', price: 19.99 },
    { name: 'Product 2', image: '/product images/jasonclone.png', price: 29.99 },
    { name: 'Product 3', image: '/product images/jasonclone.png', price: 39.99 }
  ];
  const title = 'Worst Buy';
  const siteName = 'Worst Buy';
  const productCount = 3;

  // Render the 'root.ejs' template and pass data to it
  res.render('root', {
    title,
    siteName,
    productCount,
    products
  });
});


// render the auth.ejs template and pass data to it
app.get('/auth', (req, res) => {
  res.render('auth', {
    title: 'Login/Register',
    siteName: 'Worst Buy'
  });
});


// Create a MySQL connection pool for handling database queries
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB1_NAME
});
//post vs get vs put requests:
// GET requests are used to retrieve data from the server.
// POST requests are used to send data to the server.
// PUT requests are used to update data on the server.
// DELETE requests are used to delete data from the server.




app.get('/login_request', (req, res) => { 
  res.send('You are not supposed to be here! This a protected endpoint for login POST requests only. -Jason Clone');
});

// Handle login requests
app.post('/login_request', async (req, res) => {
  const { email, password } = req.body;
  try {
    const [rows] = await pool.query('SELECT * FROM users WHERE email = ? AND password = ?', [email, password]);
    if (rows.length > 0) {
      res.status(200).json({ message: 'Login successful!' });
    } else {
      res.status(401).json({ message: 'Invalid credentials' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Error occurred' });
  }
});

app.get('/register_request', (req, res) => {
  res.send('You are not supposed to be here! This a protected endpoint for register POST requests only. -Jason Clone');
});

// Handle register requests
app.post('/register_request', async (req, res) => {
  const { email, password } = req.body;
  try {
    await pool.query('INSERT INTO users (email, password) VALUES (?, ?)', [email, password]);
    res.status(200).json({ message: 'Registration successful!' });
  } catch (error) {
    res.status(500).json({ message: 'Error occurred' });
  }
});



const HOST = '0.0.0.0'; // any IP address from the host machine
const PORT = process.env.PORT || 3000;

app.listen(PORT, HOST, () => {
  console.log(`Server is running at http://${HOST}:${PORT}`);
});
// In this example, we have two routes: /login_request and /register_request. 
//These routes handle login and registration requests, respectively. 
//When a user submits the login or register form, the client-side JavaScript code sends a 
//POST request to the corresponding route on the server.