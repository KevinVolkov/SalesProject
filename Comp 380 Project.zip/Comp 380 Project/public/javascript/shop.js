//*** shop.js is the client side code that is SPECIFICALLY for to the shop page.

document.addEventListener('DOMContentLoaded', () => { 


});
