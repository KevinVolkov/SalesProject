//********************* COPY AND PASTE THIS CODE INTO OTHER ROUTE JS FILES
// import the express router and necessary modules
const express = require('express');
const mysql = require('mysql2/promise');
const path = require('path');

// Create a new router object
const router = express.Router();
// Serve static files from the 'public' directory
router.use(express.static(path.join(__dirname, 'public')));

// Import the 'dotenv' module for loading environment variables
require('dotenv').config();

// Create a MySQL connection pool for handling database queries
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB1_NAME
});
//********************* COPY AND PASTE THIS CODE INTO OTHER ROUTE JS FILES

// render the root.ejs template and pass data to it
router.get('/', (req, res) => {
    // Sample data to pass to the template
  
    // Render the 'root.ejs' template and pass data to it
    res.render('root', {
      title: 'Home',
      siteName: 'Worst Buy',
    });
  });

module.exports = router; // Export the router object
