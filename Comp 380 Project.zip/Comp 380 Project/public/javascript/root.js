document.addEventListener('DOMContentLoaded', () => {
  // Get references to buttons and links
  const homebutton = document.getElementById('home-button'); // Home button

  // Get references to navigation links
  const searchButton = document.getElementById('search-button'); // Link to products section



  //go to home page
  homebutton.addEventListener('click', () => {
    //redirect to the home page
    window.location.href = '/'; // Redirect to the home page

  });


  // Go to shop page
  searchButton.addEventListener('click', (e) => {
    e.preventDefault(); // Prevent default link behavior
    //redirect to the shop page
    window.location.href = '/shop'; // Redirect to the shop page


  });

});
