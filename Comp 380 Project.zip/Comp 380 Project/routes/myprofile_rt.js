const express = require('express');
const router = express.Router();
const mysql = require('mysql2/promise');
require('dotenv').config();


// Create a MySQL connection pool for handling database queries
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB1_NAME,
});

//router for profile page
router
  .route("/")
   // render the root.ejs template and pass data to it
  .get((req, res) => {
    res.render('myprofile', {
      title: 'Profile',
      siteName: 'Worst Buy',
    });
  });


module.exports = router; // Export the router object
