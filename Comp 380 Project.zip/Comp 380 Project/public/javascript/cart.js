document.addEventListener("DOMContentLoaded", () => {
  // Function to check token status and display the remaining time
  const checkTokenStatus = () => {
    fetch("/cart/token_status")
      .then((response) => {
        if (response.ok) {
          return response.json();
        }
        throw new Error("Failed to fetch token status");
      })
      .then((data) => {
        const remainingTime = data.accessTokenExpiresAt; // Get the remaining time in seconds
        const minutes = Math.floor(remainingTime / 60);
        const seconds = remainingTime % 60;

        // Display the remaining time in a suitable element
        const tokenStatusElement = document.getElementById("token-status");
        if (tokenStatusElement) {
          tokenStatusElement.textContent = `Cart Access Token Expires In: ${minutes}m ${seconds}s`;
        }

        console.log(`Cart Access Token Expires In: ${remainingTime} seconds`);
      })
      .catch((error) => {
        console.error("Error fetching token status:", error);
      });
  };

  // Call the function on page load
  checkTokenStatus();

  // Update an item in the cart (PUT)
  document.querySelectorAll(".update-cart").forEach((button) => {
    button.addEventListener("click", () => {
      const productId = button.dataset.productId;
      const quantity = parseInt(
        document.querySelector(`#quantity-${productId}`).value
      );

      fetch("/cart/update", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ productId, quantity }),
      })
        .then(() => {
          window.location.reload(); // Reload the page to update cart
          checkTokenStatus(); // Check token status after updating the cart
        })
        .catch((error) => {
          console.error("Error updating cart:", error);
        });
    });
  });

  // Remove an item from the cart (DELETE)
  document.querySelectorAll(".remove-from-cart").forEach((button) => {
    button.addEventListener("click", () => {
      const productId = button.dataset.productId;

      fetch("/cart/remove", {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ productId }),
      })
        .then(() => {
          window.location.reload(); // Reload the page to update cart
          checkTokenStatus(); // Check token status after removing the item
        })
        .catch((error) => {
          console.error("Error removing item:", error);
        });
    });
  });

  // Clear the entire cart (DELETE)
  document.querySelector(".clear-cart").addEventListener("click", () => {
    fetch("/cart/clear", {
      method: "DELETE",
    })
      .then(() => {
        alert("Cart cleared successfully!");
        window.location.reload(); // Reload the page to update cart
        checkTokenStatus(); // Check token status after clearing the cart
      })
      .catch((error) => {
        alert("Error clearing cart:", error);
      });
      
  });

  // Proceed to checkout (POST)
  document
    .querySelector(".checkout-cart")
    ?.addEventListener("click", async () => {
      //redirect to checkout page
      window.location.href = "/checkout";
    });
});
