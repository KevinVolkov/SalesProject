//***root_rt.js is the main router for home page backend, its html rendering,
//*** and its necessary access/refresh tokens (if any).

// import the express router and necessary modules
const express = require("express");
const mysql = require("mysql2/promise");
const path = require("path");
const jwt = require("jsonwebtoken");
const { is } = require("type-is");
const cookieParser = require("cookie-parser");

// Create a new router object
const router = express.Router();
// Serve static files from the 'public' directory
router.use(express.static(path.join(__dirname, "public")));
// Parse cookies in the request headers
router.use(cookieParser());
// Import the 'dotenv' module for loading environment variables
require("dotenv").config();


//middleware to verify if logged in
const verifyLogin = (req, res, next) => {
  // Check if the user is logged in
  if (!req.cookies.accessToken) {
    req.isLoggedIn = false; // Not logged in
    return next(); // Proceed to the next middleware or route
  }

  // Verify the access token
  jwt.verify(req.cookies.accessToken, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
    if (err) {
      req.isLoggedIn = false; // Not logged in if token is invalid
    } else {
      req.isLoggedIn = true; // User is logged in
    }
    next(); // Proceed to the next middleware or route
  });
};

// Middleware to verify cart access token (in this case used to get cart item count for cart button)
const verifyCartAccessToken = (req, res, next) => {
  const accessToken = req.cookies.cartAccessToken;

  try {
    // Verify the access token
    const cartData = jwt.verify(
      accessToken,
      process.env.CART_ACCESS_TOKEN_SECRET
    );
    req.cart = cartData.cart; // Attach cart data to the request
  } catch (err) {
    req.cart = []; // If token is invalid or expired, set an empty cart
  }

  next(); // Proceed to the next middleware or route
};

//organizes each endpoint by http request type in the order they are written in the router object.
router
  .route("/")
   // render the root.ejs template and pass data to it
  .get(verifyLogin, verifyCartAccessToken, (req, res) => {
    loggedIn = req.isLoggedIn; // Get the 'req.isLoggedIn' from middleware
    cart = req.cart; // Get the 'req.cart' from middleware

    // Calculate total items in cart
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0); // Sum of all quantities
    res.render('root', {
      title: 'Home',
      siteName: 'Worst Buy',
      loggedIn,
      totalItems,
    });
  });


module.exports = router; // Export the router object

