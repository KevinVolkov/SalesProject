const express = require('express');
const router = express.Router();

// render the root.ejs template and pass data to it
router.get('/', (req, res) => {
    // Sample data to pass to the template
  
    // Render the 'root.ejs' template and pass data to it
    res.render('root', {
      title: 'Home',
      siteName: 'Worst Buy',
    });
  });

module.exports = router; // Export the router object
