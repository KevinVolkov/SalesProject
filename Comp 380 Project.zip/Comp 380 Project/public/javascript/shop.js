document.addEventListener('DOMContentLoaded', () => {

const loginButton = document.getElementById('login-button'); // Login button
const searchButton = document.getElementById('search-button'); // Link to products section
const homebutton = document.getElementById('home-button'); // Home button


  // Go to register/login screen (auth.ejs) when the login/register button is clicked
  loginButton.addEventListener('click', () => {
    //redirect to the auth page even if in deeper url path
    window.location.href = '/auth'; // Redirect to the auth page
  });

  searchButton.addEventListener('click', (e) => {
    e.preventDefault(); // Prevent default link behavior
    //redirect to the shop page
    window.location.href = '/shop'; // Redirect to the shop page
  });

  homebutton.addEventListener('click', () => {
    //redirect to the home page
    window.location.href = '/'; // Redirect to the home page
  });
});
