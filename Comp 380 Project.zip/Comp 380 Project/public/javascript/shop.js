//*** shop.js is the client side code that is SPECIFICALLY for to the shop page.

document.addEventListener('DOMContentLoaded', () => {

const searchButton = document.getElementById('search-button'); // Link to products section
const homebutton = document.getElementById('home-button'); // Home button




  searchButton.addEventListener('click', (e) => {
    e.preventDefault(); // Prevent default link behavior
    //redirect to the shop page
    window.location.href = '/shop'; // Redirect to the shop page
  });

  homebutton.addEventListener('click', () => {
    //redirect to the home page
    window.location.href = '/'; // Redirect to the home page
  });
});
