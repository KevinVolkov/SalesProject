-- Create 'users' table if it doesn't exist
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,     -- Unique ID for each user
    email VARCHAR(255) NOT NULL,           -- User's email (required)
    password VARCHAR(255) NOT NULL,        -- User's password (required)
    is_admin BOOLEAN DEFAULT FALSE,        -- Admin flag (default is false)
    admin_code VARCHAR(255) DEFAULT NULL   -- Admin code (nullable) used to give admin access to a user
);

-- Insert an admin user (optional) -- You can uncomment this to insert an admin user
INSERT INTO users (email, password, is_admin, admin_code) VALUES ('admin@example.com', 'adminpassword', TRUE, 'someAdminCode123');

-- display all users
SELECT * FROM users;

