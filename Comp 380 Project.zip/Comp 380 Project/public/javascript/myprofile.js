//*** myprofile.js is the client side code that is SPECIFICALLY for to the profile screen.

async function checkAccessiblity() {
  //immediately check if the user is logged in
  try {
    // Send request to the backend to check if the user is logged in

    const response = await fetch("/auth/token_status", {
      method: "GET",
      credentials: "include",
    });

    // If the user is not logged in, redirect to the login page
    if (response.status != 200) {
      window.location.href = "/auth";
    }
  } catch (error) {
    console.error("Error checking if user is logged in:", error);
  }
}
async function wrapAsyncFunction(asyncFunction) {
  try {
    await asyncFunction();
  } catch (error) {
    console.error("Error in async function:", error);
  }
}

  // check if authorized to view this page
  wrapAsyncFunction(checkAccessiblity);

document.addEventListener("DOMContentLoaded", () => {


  const homebutton = document.getElementById("home-button"); // Home button
  const logoutButton = document.getElementById("logout-button"); // Logout button

  logoutButton.addEventListener("click", async () => {
    try {
      // Send logout request to the backend
      const response = await fetch("/auth/logout", {
        method: "POST",
      });

      // Parse response data
      const result = await response.json();

      // Log the message from the response
      console.log(result.message);
      //redirect to the home page
      window.location.href = "/";
    } catch (error) {
      console.error("Error logging out:", error);
    }
  });
});
