//********************* COPY AND PASTE THIS CODE INTO OTHER ROUTE JS FILES
// import the express router and necessary modules
const express = require('express');
const mysql = require('mysql2/promise');
const path = require('path');

// Create a new router object
const router = express.Router();
// Serve static files from the 'public' directory
router.use(express.static(path.join(__dirname, 'public')));

// Import the 'dotenv' module for loading environment variables
require('dotenv').config();

// Create a MySQL connection pool for handling database queries
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB1_NAME
});
//********************* COPY AND PASTE THIS CODE INTO OTHER ROUTE JS FILES

// render the auth.ejs template and pass data to it
router.get('/', (req, res) => {
    res.render('auth', {
      title: 'Login/Register',
      siteName: 'Worst Buy'
    });
  });
  
  
  router.get('/login_request', (req, res) => { 
    res.send('You are not supposed to be here! -Jason Clone');
  });
  
  // Handle login requests
  router.post('/login_request', async (req, res) => {
    const { email, password } = req.body;
    try {
      const [rows] = await pool.query('SELECT * FROM users WHERE email = ? AND password = ?', [email, password]);
      if (rows.length > 0) {
        res.status(200).json({ message: 'Login successful!' });
        console.log('Login successful!');
      } else {
        res.status(401).json({ message: 'Invalid credentials' });
      }
    } catch (error) {
      res.status(500).json({ message: 'Error occurred' });
    }
  });
  
  router.get('/register_request', (req, res) => {
    res.send('You are not supposed to be here!  -Jason Clone');
  });
  
  // Handle register requests
  router.post('/register_request', async (req, res) => {
    const { email, password } = req.body;
    try {
      await pool.query('INSERT INTO users (email, password) VALUES (?, ?)', [email, password]);
      res.status(200).json({ message: 'Registration successful!' });
    } catch (error) {
      res.status(500).json({ message: 'Error occurred' });
    }
  });
  
module.exports = router; //export the router object