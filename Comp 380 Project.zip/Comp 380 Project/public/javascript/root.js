document.addEventListener('DOMContentLoaded', () => {
  // Get references to buttons and links
  const loginButton = document.getElementById('login-button'); // Login button


  // Get references to navigation links
  const shop = document.getElementById('search-bar'); // Link to products section

  // Go to register/login screen (auth.ejs) when the login/register button is clicked
  loginButton.addEventListener('click', () => {
    //redirect to the auth page
    window.location.href = '/auth'; // Redirect to the auth page

  });


  // Go to shop page
  shop.addEventListener('click', (e) => {
    e.preventDefault(); // Prevent default link behavior
    //redirect to the shop page

  });

});
