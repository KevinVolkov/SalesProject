// checkout.js
document.addEventListener("DOMContentLoaded", () => {
  document
    .getElementById("checkout-form")
    .addEventListener("submit", async (e) => {
      e.preventDefault();

      const formData = new FormData(e.target);
      const data = Object.fromEntries(formData.entries()); // Convert form data to object which is a better format for JSON

      try {
        const response = await fetch("/checkout", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        });

        const result = await response.json();

        document.getElementById("message").textContent =
          result.message || "Checkout completed!";

        if (response.ok) {
          //alert on screen that displays checkout info and total price
          alert(
            `Checkout completed!
            Total price: $${result.price}
            Order details: ${result.cartData
               .map((item) => `${item.name} x ${item.quantity}`)
               .join(", ")}
            Shipping info:
              Name: ${result.checkoutData.name}
              Address: ${result.checkoutData.address}
              City: ${result.checkoutData.city}
              State: ${result.checkoutData.state}
              Zip: ${result.checkoutData.zip}
              Email: ${result.checkoutData.email}
            Shipping method: ${result.checkoutData["shipping-method"]}`
          );
        } else {
          alert("ERROR: " + result.message); //alert on screen that displays error message
        }

        //reload page
        window.location.reload();
      } catch (error) {
        console.error("Error:", error);
        document.getElementById("message").textContent =
          "There was an error during checkout.";
      }
    });
});
