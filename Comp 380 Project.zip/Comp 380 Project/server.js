// server.js

// Core modules
const express = require("express");
const mysql = require("mysql2/promise");
const path = require("path");
const https = require("https");
const fs = require("fs");
const os = require("os"); // Import the os module to get private IP of server host

// Third-party modules
const helmet = require("helmet"); // Helmet for site security 
const axios = require("axios"); // Import axios to get public IP
require("dotenv").config(); // Load environment variables from a .env file into process.env

//** Create Express app
const app = express();

//** Middleware setup
// Body parsers
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Helmet security middleware
app.use(helmet()); // Helmet applied after body parsers because the parsers are needed to parse POST requests

// Serve static files (e.g., images, CSS, JavaScript)
app.use(express.static(path.join(__dirname, "public")));

// Set up EJS as the view engine
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");

//** Imported config 
// Import verifyDatabase function from dbConfig.js
const { verifyDatabase } = require("./config/dbconfig.js");


//** Import custom middleware


// Set up SSL options
let sslOptions;
try {
  sslOptions = {
    key: fs.readFileSync(path.join(__dirname, "certs", "privkey3.pem")),
    cert: fs.readFileSync(path.join(__dirname, "certs", "cert3.pem")),
    ca: fs.readFileSync(path.join(__dirname, "certs", "chain3.pem")),
  };
} catch (error) {
  console.error("Failed to load SSL certificates:", error);
  process.exit(1); // Exit if SSL options cannot be set
}

//** Define routers
const rootRouter = require("./routes/root_rt");
app.use("/", rootRouter);
const authRouter = require("./routes/auth_rt");
app.use("/auth", authRouter);
const shopRouter = require("./routes/shop_rt");
app.use("/shop", shopRouter);
const cartRouter = require("./routes/cart_rt");
app.use("/cart", cartRouter);
const checkoutRouter = require("./routes/checkout_rt");
app.use("/checkout", checkoutRouter);
const myprofileRouter = require("./routes/myprofile_rt");
app.use("/myprofile", myprofileRouter);

// Utility function to fetch the public IP address of the server's host
async function getPublicIP() {
  try {
    const response = await axios.get("https://api.ipify.org?format=json");
    return response.data.ip;
  } catch (error) {
    console.error("Error fetching public IP:", error);
    return "(ERR: CANNOT GET PUBLIC IP)"; // Return null if there's an error
  }
}

// get the private IP address of the server's host (to connect from other devices on the same network)
function getPrivateIP() {
  const networkInterfaces = os.networkInterfaces();
  let privateIP = '';

  for (const interfaceKey in networkInterfaces) { // network interface means a
    const networkInterface = networkInterfaces[interfaceKey];

    for (const address of networkInterface) {
      // Check for IPv4 address that is not a loopback address
      if (address.family === 'IPv4' && !address.internal) {
        privateIP = address.address; // Set the private IP as the first non-internal IPv4 address
        break; // Found the first non-internal IPv4 address
      }
    }
    if (privateIP) break; // Exit if we have found a private IP
  }
  return privateIP || 'No private IP found';
}

// Start the HTTPS server after initializing the database
async function launchSite() {
  try {
    await verifyDatabase(); // Verify and initialize the database

    const httpsServer = https.createServer(sslOptions, app);
    const publicIP = await getPublicIP(); // Get the public IP of the server's host
    const privateIP = getPrivateIP(); // Get the private IP of the server's host
    const HOST = "0.0.0.0"; // Accept connections from all IPs (even public ones)
    const PORT = process.env.PORT || 443;

    httpsServer.listen(PORT, HOST, () => {
      console.log(`
-----------------------------------------------------------------------------------------------------------------
Worst Buy HTTPS Server is running at:
-----------------------------------------------------------------------------------------------------------------
Local:  https://localhost:${PORT}         (accessible only on this machine) 
        https://${privateIP}:${PORT}      (for other devices on the same network)

Public: https://${publicIP}:${PORT}   (Make sure Network Firewall allows Port ${PORT} for inbound connections)
-----------------------------------------------------------------------------------------------------------------
\n`);
});


  } catch (error) {
    console.error("Site could not be launched!:", error);
  }
}

//** Driver code
launchSite();


