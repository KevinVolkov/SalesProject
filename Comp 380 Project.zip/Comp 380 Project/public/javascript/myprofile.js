document.addEventListener("DOMContentLoaded", () => {
  const logoutButton = document.getElementById("logout-button"); // Logout button
  const submitAdminCodeButton = document.getElementById("submit-admin-code");
  const sendAdminCodeButton = document.getElementById("send-admin-code");
  const adminCodeInput = document.getElementById("admin-code-input");
  const adminMessage = document.getElementById("admin-message");

    // Check if the logout button exists
    if (!logoutButton) {
      console.error("Logout button not found");
      return; // Exit if the button is not found
    }
    
  // Handle admin code submission
  submitAdminCodeButton.addEventListener("click", async () => {
    const adminCode = adminCodeInput.value;
    try {
      const response = await fetch("/myprofile/verify_admin_code", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ adminCode }),
      });

      const result = await response.json();
      console.log("Response from verifying admin code:", result); // Log the response from the server

      alert(result.message); // Notify user about the result

      if (response.ok) {
        // Code was correct, reload or update the UI
        location.reload();
      }
    } catch (error) {
      console.error("Error verifying admin code:", error);
    }
  });

  // Handle sending for admin code
  sendAdminCodeButton.addEventListener("click", async () => {
    try {
      const response = await fetch("/myprofile/send_admin_code", {
        method: "POST",
        credentials: "include",
      });

      const result = await response.json();
      console.log("Response from sending for admin code:", result); // Log the response from the server

      alert(result.message); // Notify user about the result

      if (response.ok) {
        // Hide send button and display the message
        sendAdminCodeButton.style.display = "none";
        adminMessage.textContent =
          "Code sent to site host's email. Wait for them to verify you as an admin. You will be emailed confirmation when you are.";
        adminMessage.style.display = "block";
      }
    } catch (error) {
      console.error("Error sending for admin code:", error);
    }
  });

  document.getElementById('logout-button').addEventListener('click', async () => {
    try {
      const response = await fetch('/myprofile/logout', {
        method: 'POST',
        credentials: 'include', // Include cookies in the request
        headers: {
          'Content-Type': 'application/json'
        },
      });
  
      const data = await response.json();
  
      if (response.ok) {
        // Handle successful logout (e.g., redirect to home or login page)
        alert(data.message);
        window.location.href = '/'; // Redirect to home
      } else {
        // Handle error response
        alert(data.message);
      }
    } catch (error) {
      console.error("Error during logout:", error);
      alert("An error occurred while logging out. Please try again.");
    }
  });
  
  
});
