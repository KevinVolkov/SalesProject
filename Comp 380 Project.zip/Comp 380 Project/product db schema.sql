-- Create 'products' table if it doesn't exist
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY, -- Unique ID for each product
    name VARCHAR(255) NOT NULL, -- Product name
    description TEXT, -- Product description
    price DECIMAL(10, 2) NOT NULL, -- Product price
    image_url VARCHAR(255), -- URL to product image
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
SELECT * FROM products;
-- Insert a sample product (optional) -- You can uncomment this to insert a sample product
INSERT INTO products (name, description, price, image_url) VALUES ('Sample Product', 'This is a sample product', 9.99, 'https://static.vecteezy.com/system/resources/thumbnails/036/025/219/small/ai-generated-happy-fat-man-in-a-blue-t-shirt-showing-thumb-up-photo.jpg');