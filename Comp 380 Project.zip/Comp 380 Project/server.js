// server.js
const express = require("express");
const mysql = require("mysql2/promise");
const path = require("path");
require("dotenv").config();
const app = express();
app.use(express.json());
const https = require("https");
const fs = require("fs");
const axios = require("axios"); // import axios to get public IP

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, "public"))); // gives access to public folder

// Set up EJS as the view engine
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");

// Import verifyDatabase fn from dbConfig.js
const { verifyDatabase } = require("./config/dbconfig.js"); 

// Set up SSL options
let sslOptions;
try {
  sslOptions = {
    key: fs.readFileSync(path.join(__dirname, "certs", "privkey3.pem")),
    cert: fs.readFileSync(path.join(__dirname, "certs", "cert3.pem")),
    ca: fs.readFileSync(path.join(__dirname, "certs", "chain3.pem")),
  };
} catch (error) {
  console.error("Failed to load SSL certificates:", error);
  process.exit(1); // Exit if SSL options cannot be set
}

// Define routers
const rootRouter = require("./routes/root_rt"); 
app.use("/", rootRouter); 
const authRouter = require("./routes/auth_rt"); 
app.use("/auth", authRouter); 
const shopRouter = require("./routes/shop_rt"); 
app.use("/shop", shopRouter); 
const cartRouter = require("./routes/cart_rt"); 
app.use("/cart", cartRouter); 
const checkoutRouter = require("./routes/checkout_rt"); 
app.use("/checkout", checkoutRouter); 
const myprofileRouter = require("./routes/myprofile_rt"); 
app.use("/myprofile", myprofileRouter); 




// util function to get public IP server.js is running on
async function getPublicIP() {
  try {
    const response = await axios.get('https://api.ipify.org?format=json');
    return response.data.ip;
  } catch (error) {
    console.error('Error fetching public IP:', error);
    return null; // Return null if there's an error
  }
}

// Start the HTTPS server after initializing the database
async function launchSite() {
  try {
    await verifyDatabase(); // Verify and initialize the database


    const httpsServer = https.createServer(sslOptions, app);
    const publicIP = await getPublicIP(); // Get the public IP of the server
    const HOST = "0.0.0.0"; // Accept connections from all IPs (even public ones)
    const PORT = process.env.PORT || 443;

    httpsServer.listen(PORT, HOST, () => {
      console.log(`
Worst Buy HTTPS Server is running at 
Locally:    https://localhost:${PORT}  
Publically: https://${publicIP}:${PORT} (Make sure Network Firewall allows Port ${PORT} for inbound connections)`);
    });

    // Handle graceful shutdown when process is terminated (signal interrupt)
    process.on('SIGINT', async () => {
      console.log("Received SIGINT. Shutting down gracefully...");
      // Perform any cleanup tasks here if needed

      httpsServer.close(() => {
        console.log("Server shut down gracefully.");
        process.exit(0); // Exit gracefully
      });
    });
  } catch (error) {
    console.error("Site could not be launched!:", error);
  }
}

// Driver code
launchSite();
