//***auth_rt.js is the main router for user authentication backend, its html rendering,
//*** and its necessary access/refresh tokens (if any).

// import the express router and necessary modules
const express = require("express");
const mysql = require("mysql2/promise");
const path = require("path");
const jwt = require("jsonwebtoken");
const { is } = require("type-is");
const cookieParser = require("cookie-parser");

// Create a new router object
const router = express.Router();
// Serve static files from the 'public' directory
router.use(express.static(path.join(__dirname, "public")));
// Parse cookies in the request headers
router.use(cookieParser());
// Import the 'dotenv' module for loading environment variables
require("dotenv").config();

// Database for users
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB1_NAME,
});


// Generate Access Token
function generateAccessToken(user) {
  return jwt.sign(user, process.env.ACCESS_TOKEN_SECRET, { expiresIn: "5s" });
}

// Generate Refresh Token
function generateRefreshToken(user) {
  return jwt.sign(user, process.env.REFRESH_TOKEN_SECRET, { expiresIn: "1m" });
}

// main router (auth.ejs form)
router.route("/").get((req, res) => {
  res.render("auth", {
    title: "Login/Register",
    siteName: "Worst Buy",
  });
});

// Route to get token expiration times
router.route("/token_status").get((req, res) => {
  const accessToken = req.cookies.accessToken;
  const refreshToken = req.cookies.refreshToken;

  if (!refreshToken) {
    return res
      .status(403)
      .json({ message: "No refresh token found! (You must not be logged in)" }); // Forbidden if no refresh token
  }

  // Decode and get expiration times
  try {
    const accessTokenPayload = jwt.verify(
      accessToken,
      process.env.ACCESS_TOKEN_SECRET,
      { complete: true }
    );
    const refreshTokenPayload = jwt.verify(
      refreshToken,
      process.env.REFRESH_TOKEN_SECRET,
      { complete: true }
    );

    const currentTime = Math.floor(Date.now() / 1000); // Current time in seconds
    // Calculate the time remaining for each token by subtracting the current time
    // from the expiration time. Use the ternary operator to handle cases where
    // the expiration time might be undefined, ensuring a default value of 0.
    const accessTokenExpiresAt = accessTokenPayload.payload.exp
      ? accessTokenPayload.payload.exp - currentTime
      : 0;
    const refreshTokenExpiresAt = refreshTokenPayload.payload.exp
      ? refreshTokenPayload.payload.exp - currentTime
      : 0;

    console.log(`Access Token Expires In: ${accessTokenExpiresAt} seconds`);
    console.log(`Refresh Token Expires In: ${refreshTokenExpiresAt} seconds`);

    res.status(200).json({
      // Send the time remaining in seconds as a response
      accessTokenExpiresAt,
      refreshTokenExpiresAt,
    });
  } catch (err) {
    return res
      .status(403)
      .json({
        message: "Invalid tokens. Cannot display time remaining of each",
      });
  }
});

// Refresh token endpoint (***only use .json with status not sendStatus)
router
  .route("/restart_token")
  .post((req, res) => {
    //post request to refresh the access token
    const refreshToken = req.cookies.refreshToken;

    if (!refreshToken)
      
      return res
        .status(403)
        .json({
          message: "No refresh token found! (You must not be logged in)",
        }); // Forbidden if no refresh token

    // Verify refresh token
    jwt.verify(refreshToken, process.env.REFRESH_TOKEN_SECRET, (err, user) => {
      if (err) {
        return res
          .status(403)
          .json({
            message: "Invalid refresh token: jwt.verify(refreshtoken) failed",
          });
      }

      // Generate a new access token
      const accessToken = generateAccessToken({ email: user.email });
      // Send the new access token as a cookie. It will replace the old access token
      res.cookie("accessToken", accessToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        maxAge: 1 * 60 * 1000, // 1 minutes
      });

      return res.status(200).json({ message: "Access Token refreshed!" });
    });
  })
  //.get request that receives the user object stored in the access token
  .get((req, res) => {
    const accessToken = req.cookies.accessToken;

    if (!accessToken)
      return res.status(403).json({ message: "No access token found!" }); // Forbidden if no access token

    // Verify access token
    jwt.verify(accessToken, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
      if (err) {
        return res
          .status(403)
          .json({
            message: "Invalid access token: jwt.verify(accesstoken) failed",
          });
      }
      //send back user object
      return res.status(200).json({ user });
    });
  });

router
  .route("/login_request")
  .get((req, res) => {
    res.send("You are not supposed to be here! -Jason Clone");
  })
  .post(async (req, res) => {
    const { email, password } = req.body;
    try {
      const [rows] = await pool.query(
        "SELECT * FROM users WHERE email = ? AND password = ?",
        [email, password]
      );
      if (rows.length > 0) {
        const user = { email: email }; // Store user's email in the token payload

        // Generate tokens
        const accessToken = generateAccessToken(user);
        const refreshToken = generateRefreshToken(user);

        // Set cookies for tokens
        res.cookie("accessToken", accessToken, {
          httpOnly: true,
          secure: process.env.NODE_ENV === "production",
          maxAge: 1 * 60 * 1000, // 1 minutes
        });

        res.cookie("refreshToken", refreshToken, {
          httpOnly: true,
          secure: process.env.NODE_ENV === "production",
          maxAge: 1 * 60 * 1000, // 1 minutes
        });
        return res.status(200).json({ message: "Login successful!" });
      } else {
        return res.status(401).json({ message: "Invalid credentials" });
      }
    } catch (error) {
      return res
        .status(500)
        .json({ message: "Error occurred with mysql database or query" });
    }
  });

router
  .route("/register_request")
  .get((req, res) => {
    res.send("You are not supposed to be here! -Jason Clone");
  })
  .post(async (req, res) => {
    const { email, password } = req.body;
    try {
      await pool.query("INSERT INTO users (email, password) VALUES (?, ?)", [
        email,
        password,
      ]);
      return res.status(200).json({ message: "Registration successful!" });
    } catch (error) {
      return res
        .status(500)
        .json({
          message:
            "Error occurred with mysql database or credentials already registered",
        });
    }
  });

// Route to log out and clear cookies
router.route("/logout").post((req, res) => {
  try {
    // Clear cookies
    res.clearCookie("accessToken", {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
    });
    res.clearCookie("refreshToken", {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
    });
    return res.status(200).json({ message: "Logged out and cookies cleared!" });
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Error clearing cookies. Check status of cookies" });
  }
});

module.exports = router;
