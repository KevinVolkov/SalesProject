// Imports and Initial Setup
const express = require('express');
// const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
const stripe = require('stripe')('your_stripe_secret_key');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');
const https = require('https');
const session = require('express-session');
const flash = require('connect-flash');

// Database and Model Imports
const sequelize = require('./config/db');
const createDatabase = require('./config/createDatabase');
const populateItemsIfEmpty = require('./config/populateItems');
const Customer = require('./models/Customer');
const customerRoutes = require('./routes/customers');
const itemsRoute = require('./routes/items');
const orderRoute = require('./routes/order');

// SSL Configuration
const options = {
  key: fs.readFileSync(path.join(__dirname, 'key.pem')),
  cert: fs.readFileSync(path.join(__dirname, 'cert.pem'))
};

// Initialize Express App
const app = express();

// Session and Middleware Configuration
app.use(session({
  secret: 'yourSecretKey',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } // set to true in production with HTTPS
}));
app.use(flash());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Set View Engine
app.set('view engine', 'ejs');

// Middleware to Set Local Variables
app.use((req, res, next) => {
  res.locals.customer = req.session.customer || null;
  res.locals.cartCount = (req.session.cart || []).length;
  next();
});

// Route Handlers
app.use('/customers', customerRoutes);
app.use('/items', itemsRoute);
app.use('/order', orderRoute);

// Main Routes
app.get('/', (req, res) => {
  res.render('index', {
    title: 'Welcome to ABC Sales',
    user: req.user,
    cartCount: res.locals.cartCount
  });
});

app.get('/checkout', (req, res) => {
  if (!req.session.customer) {
    return res.redirect('/customers/login');
  }
  res.render('checkout', {
    customer: req.session.customer,
    user: req.user
  });
});

app.get('/login', (req, res) => {
  res.render('login', {
    title: 'Please Login to ABC Sales',
    user: req.user
  });
});

app.get('/register', (req, res) => {
  res.render('register', {
    title: 'Please Register with ABC Sales',
    user: req.user
  });
});

app.get('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) return res.redirect('/');
    res.redirect('/');
  });
});

// Database Initialization and Server Start
async function initializeDatabase() {
  try {
    console.log('Creating database...');
    await createDatabase();
    
    console.log('Starting database synchronization...');
    await sequelize.sync({ alter: { drop: false } });
    
    console.log('Populating items if empty...');
    await populateItemsIfEmpty();

    console.log('initializeDatabase() COMPLETE: MySql Database initialized successfully!');
    
  } catch (error) {
    console.error('initializeDatabase() FAILED: Unable to connect to MySQL:', error);
  }
}


// Prepare database
initializeDatabase();

// HTTPS Server Creation and Start
const server = https.createServer(options, app);
const PORT = 3000; // Adjust the port if needed
server.listen(PORT, () => {
  console.log(`Server running securely (https) on port ${PORT}`);
});
